"""Code search functionality using ripgrep for fast pattern matching."""

import subprocess
from dataclasses import dataclass
from pathlib import Path


class SearchError(Exception):
    """Base exception for search errors."""

    pass


class RipgrepNotFoundError(SearchError):
    """Raised when ripgrep is not available on the system."""

    pass


@dataclass
class SearchMatch:
    """Container for a single search match.

    Attributes:
        file_path: Path to the file containing the match
        line_number: Line number where the match was found
        line_content: Content of the matching line
    """

    file_path: Path
    line_number: int
    line_content: str


@dataclass
class SearchResult:
    """Container for search results and metadata.

    Attributes:
        query: The search pattern used
        matches: List of search matches found
        total_matches: Total number of matches found
        truncated: Whether results were truncated due to limit
        case_sensitive: Whether the search was case-sensitive
    """

    query: str
    matches: list[SearchMatch]
    total_matches: int
    truncated: bool
    case_sensitive: bool


class CodeSearcher:
    """Handles code search operations using ripgrep."""

    def __init__(
        self,
        working_dir: Path | None = None,
        max_results: int = 20
    ) -> None:
        """Initialize CodeSearcher.

        Args:
            working_dir: Base directory for searches (default: current directory)
            max_results: Maximum number of results to return

        Raises:
            RipgrepNotFoundError: If ripgrep is not available on the system
        """
        self.working_dir = working_dir if working_dir else Path.cwd()
        self.max_results = max_results

        # Check if ripgrep is available
        if not self._is_ripgrep_available():
            raise RipgrepNotFoundError(
                "ripgrep (rg) is not installed or not in PATH. "
                "Please install it: https://github.com/BurntSushi/ripgrep"
            )

    def _is_ripgrep_available(self) -> bool:
        """Check if ripgrep is available on the system.

        Returns:
            True if ripgrep is available, False otherwise
        """
        try:
            result = subprocess.run(
                ["rg", "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def search(
        self,
        pattern: str,
        glob: str | None = None,
        case_sensitive: bool = False
    ) -> SearchResult:
        """Search for a pattern in files.

        Args:
            pattern: Regular expression pattern to search for
            glob: Optional glob pattern to filter files (e.g., "*.py", "**/*.js")
            case_sensitive: Whether to perform case-sensitive search

        Returns:
            SearchResult object containing matches

        Raises:
            SearchError: If the search operation fails
        """
        # Build ripgrep command
        cmd = ["rg"]

        # Add case sensitivity flag
        if not case_sensitive:
            cmd.append("--ignore-case")

        # Add line number and context flags
        cmd.extend([
            "--line-number",  # Show line numbers
            "--no-heading",   # Don't group by file (easier to parse)
            "--with-filename", # Always show filename
            "--max-count", str(self.max_results),  # Limit matches per file
        ])

        # Add glob pattern if provided
        if glob:
            cmd.extend(["--glob", glob])

        # Add the search pattern
        cmd.append(pattern)

        # Add the working directory
        cmd.append(str(self.working_dir))

        try:
            # Run ripgrep
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30  # 30 second timeout
            )

            # Parse the output
            matches = self._parse_rg_output(result.stdout)

            # Check if we hit the limit
            truncated = len(matches) >= self.max_results

            return SearchResult(
                query=pattern,
                matches=matches[:self.max_results],
                total_matches=len(matches),
                truncated=truncated,
                case_sensitive=case_sensitive
            )

        except subprocess.TimeoutExpired as e:
            raise SearchError(
                f"Search timed out after 30 seconds for pattern: {pattern}"
            ) from e
        except Exception as e:
            raise SearchError(
                f"Error during search for pattern '{pattern}': {e}"
            ) from e

    def _parse_rg_output(self, output: str) -> list[SearchMatch]:
        """Parse ripgrep output into SearchMatch objects.

        Args:
            output: Raw ripgrep output

        Returns:
            List of SearchMatch objects
        """
        matches: list[SearchMatch] = []

        if not output.strip():
            return matches

        for line in output.strip().split("\n"):
            # ripgrep output format: filename:line_number:line_content
            parts = line.split(":", 2)
            if len(parts) >= 3:
                file_path = Path(parts[0])
                try:
                    line_number = int(parts[1])
                    line_content = parts[2]

                    matches.append(SearchMatch(
                        file_path=file_path,
                        line_number=line_number,
                        line_content=line_content
                    ))
                except ValueError:
                    # Skip lines that don't have valid line numbers
                    continue

        return matches
