"""Context management for conversation history."""

from dataclasses import dataclass
from typing import Any


@dataclass
class ContextStats:
    """Statistics about the current conversation context.

    Attributes:
        total_messages: Total number of messages in history
        estimated_tokens: Estimated token count
        has_system_prompt: Whether system prompt is present
        user_messages: Number of user messages
        assistant_messages: Number of assistant messages
    """

    total_messages: int
    estimated_tokens: int
    has_system_prompt: bool
    user_messages: int
    assistant_messages: int


class ContextManager:
    """Manages conversation context and handles trimming when needed."""

    # Approximate token limits for common models
    # These are conservative estimates to avoid hitting limits
    DEFAULT_CONTEXT_LIMIT = 8192  # Common for many models
    LARGE_CONTEXT_LIMIT = 32768  # For newer models like llama3

    # Characters per token approximation (rough heuristic)
    # Most models use ~4 characters per token on average
    CHARS_PER_TOKEN = 4

    def __init__(self, context_limit: int | None = None) -> None:
        """Initialize context manager.

        Args:
            context_limit: Maximum context size in tokens (defaults to 8192)
        """
        self.context_limit = context_limit or self.DEFAULT_CONTEXT_LIMIT

    def estimate_tokens(self, text: str) -> int:
        """Estimate token count for a text string.

        This is a rough approximation. Actual tokenization varies by model.

        Args:
            text: Text to estimate tokens for

        Returns:
            Estimated token count
        """
        # Simple character-based estimation
        # This is not perfect but works reasonably well
        return max(1, len(text) // self.CHARS_PER_TOKEN)

    def estimate_message_tokens(self, message: dict[str, Any]) -> int:
        """Estimate token count for a single message.

        Args:
            message: Message dict with 'role' and 'content'

        Returns:
            Estimated token count including role overhead
        """
        content = message.get("content", "")
        role = message.get("role", "")

        # Add overhead for role and structure
        # Format is typically: <role>: <content>
        overhead = 10  # Rough estimate for role, separators, etc.

        return self.estimate_tokens(content) + self.estimate_tokens(role) + overhead

    def get_context_stats(
        self, conversation_history: list[dict[str, Any]]
    ) -> ContextStats:
        """Calculate statistics about the conversation context.

        Args:
            conversation_history: List of message dicts

        Returns:
            ContextStats object with context information
        """
        total_messages = len(conversation_history)
        total_tokens = sum(
            self.estimate_message_tokens(msg) for msg in conversation_history
        )

        # Count messages by role
        has_system_prompt = any(msg.get("role") == "system" for msg in conversation_history)
        user_messages = sum(1 for msg in conversation_history if msg.get("role") == "user")
        assistant_messages = sum(
            1 for msg in conversation_history if msg.get("role") == "assistant"
        )

        return ContextStats(
            total_messages=total_messages,
            estimated_tokens=total_tokens,
            has_system_prompt=has_system_prompt,
            user_messages=user_messages,
            assistant_messages=assistant_messages,
        )

    def should_trim_context(
        self, conversation_history: list[dict[str, Any]]
    ) -> bool:
        """Check if context should be trimmed.

        Args:
            conversation_history: List of message dicts

        Returns:
            True if context should be trimmed
        """
        stats = self.get_context_stats(conversation_history)

        # Trim if we're at 80% of the limit to leave room for response
        threshold = int(self.context_limit * 0.8)

        return stats.estimated_tokens > threshold

    def trim_context(
        self,
        conversation_history: list[dict[str, Any]],
        preserve_recent: int = 4,
    ) -> list[dict[str, Any]]:
        """Trim conversation context to fit within limits.

        Strategy:
        1. Always preserve system prompt (if present)
        2. Always preserve the most recent N messages
        3. Remove older messages from the middle

        Args:
            conversation_history: List of message dicts
            preserve_recent: Number of recent messages to always keep

        Returns:
            Trimmed conversation history
        """
        if len(conversation_history) <= preserve_recent + 1:
            # Too short to trim meaningfully
            return conversation_history

        # Find system prompt (should be first message if present)
        system_prompt: list[dict[str, Any]] = []
        start_idx = 0

        if (
            conversation_history
            and conversation_history[0].get("role") == "system"
        ):
            system_prompt = [conversation_history[0]]
            start_idx = 1

        # Keep recent messages
        recent_messages = conversation_history[-preserve_recent:]

        # Try to fit as many middle messages as possible
        middle_messages = conversation_history[start_idx:-preserve_recent]

        # Build trimmed history by removing oldest middle messages first
        while middle_messages:
            candidate_history = system_prompt + middle_messages + recent_messages
            stats = self.get_context_stats(candidate_history)

            if stats.estimated_tokens <= int(self.context_limit * 0.7):
                # Fits comfortably
                return candidate_history

            # Remove oldest middle message
            middle_messages = middle_messages[1:]

        # If we still can't fit, just use system prompt + recent messages
        return system_prompt + recent_messages

    def format_stats_display(self, stats: ContextStats) -> str:
        """Format context stats for display.

        Args:
            stats: ContextStats object

        Returns:
            Formatted string for display
        """
        lines = [
            "## Context Statistics",
            "",
            f"- **Total Messages**: {stats.total_messages}",
            f"- **User Messages**: {stats.user_messages}",
            f"- **Assistant Messages**: {stats.assistant_messages}",
            f"- **System Prompt**: {'Yes' if stats.has_system_prompt else 'No'}",
            f"- **Estimated Tokens**: {stats.estimated_tokens:,}",
            f"- **Context Limit**: {self.context_limit:,} tokens",
        ]

        # Calculate percentage
        percentage = (stats.estimated_tokens / self.context_limit) * 100
        lines.append(f"- **Usage**: {percentage:.1f}%")

        # Add warning if approaching limit
        if percentage > 80:
            lines.append("")
            lines.append("⚠️  **Warning**: Context is approaching limit. Consider using `/clear` or "
                        "continuing conversation in a new session.")
        elif percentage > 60:
            lines.append("")
            lines.append("ℹ️  Context usage is moderate. Automatic trimming will occur if needed.")

        return "\n".join(lines)
