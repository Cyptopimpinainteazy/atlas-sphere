"""Tool calling system for autonomous LLM agent behavior."""

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass


@dataclass
class ToolCall:
    """Represents a single tool call from the LLM.

    Attributes:
        tool_name: Name of the tool to invoke
        parameters: Dictionary of parameters for the tool
        raw_xml: The original XML string for this tool call
    """

    tool_name: str
    parameters: dict[str, str]
    raw_xml: str


@dataclass
class ToolResult:
    """Represents the result of executing a tool.

    Attributes:
        tool_name: Name of the tool that was executed
        success: Whether the tool execution succeeded
        output: Output from the tool execution
        error: Error message if execution failed
    """

    tool_name: str
    success: bool
    output: str
    error: str | None = None


class ToolCallParser:
    """Parser for extracting tool calls from LLM responses."""

    def __init__(self) -> None:
        """Initialize the tool call parser."""
        # Pattern to find tool_use blocks in XML format
        self.tool_pattern = re.compile(
            r"<tool_use>(.*?)</tool_use>",
            re.DOTALL
        )

    def parse_response(self, response: str) -> tuple[list[ToolCall], str]:
        """Parse LLM response to extract tool calls and remaining text.

        Args:
            response: The LLM's response text

        Returns:
            Tuple of (list of ToolCall objects, cleaned response text without tool calls)
        """
        tool_calls: list[ToolCall] = []

        # Find all tool_use blocks
        matches = self.tool_pattern.findall(response)

        for match in matches:
            try:
                tool_call = self._parse_tool_call(match)
                if tool_call:
                    tool_calls.append(tool_call)
            except Exception:
                # Skip malformed tool calls
                continue

        # Remove tool_use blocks from the response text
        cleaned_response = self.tool_pattern.sub("", response).strip()

        return tool_calls, cleaned_response

    def _parse_tool_call(self, xml_content: str) -> ToolCall | None:
        """Parse a single tool call from XML content.

        Args:
            xml_content: The content inside <tool_use> tags

        Returns:
            ToolCall object or None if parsing fails
        """
        try:
            # Wrap in a root element for parsing
            xml_str = f"<root>{xml_content}</root>"
            root = ET.fromstring(xml_str)

            # Extract tool name
            tool_name_elem = root.find("tool_name")
            if tool_name_elem is None or not tool_name_elem.text:
                return None
            tool_name = tool_name_elem.text.strip()

            # Extract parameters
            parameters: dict[str, str] = {}
            params_elem = root.find("parameters")
            if params_elem is not None:
                for child in params_elem:
                    if child.text:
                        parameters[child.tag] = child.text.strip()

            return ToolCall(
                tool_name=tool_name,
                parameters=parameters,
                raw_xml=f"<tool_use>{xml_content}</tool_use>"
            )
        except ET.ParseError:
            return None


def get_system_prompt() -> str:
    """Get the system prompt that instructs the LLM on tool usage.

    Returns:
        System prompt string with tool usage instructions
    """
    return """You are Ralph, an autonomous coding assistant that helps developers with \
their codebase.

You have access to the following tools to help you accomplish tasks:

## Available Tools

1. **read_file** - Read the contents of a file
   Parameters:
   - file_path: Path to the file (relative or absolute)

2. **search_code** - Search for patterns in the codebase
   Parameters:
   - pattern: The search pattern/text to find
   - glob: (optional) File glob pattern like '*.py'
   - case_sensitive: (optional) 'true' or 'false', defaults to 'true'

3. **write_file** - Create or overwrite a file
   Parameters:
   - file_path: Path to the file
   - content: Content to write to the file

4. **replace_in_file** - Replace text in an existing file
   Parameters:
   - file_path: Path to the file
   - search: Text to search for
   - replace: Text to replace it with

5. **execute_command** - Execute a shell command
   Parameters:
   - command: The command to execute

## How to Use Tools

When you need to use a tool, output it in this XML format:

<tool_use>
<tool_name>read_file</tool_name>
<parameters>
<file_path>src/main.py</file_path>
</parameters>
</tool_use>

You can use multiple tools in sequence within your response. After using tools, you can \
continue explaining or providing context.

## When to Use Tools

- Use **read_file** when you need to see the contents of a file before making \
suggestions or edits
- Use **search_code** when you need to find specific patterns, functions, or references \
across the codebase
- Use **write_file** when creating new files or completely rewriting existing ones
- Use **replace_in_file** for targeted edits to existing files (more precise than \
write_file)
- Use **execute_command** to run tests, check build status, install dependencies, etc.

## Important Guidelines

1. **Always read before editing**: Read files before making changes to understand context
2. **Search before assuming**: Use search to find where things are defined or used
3. **Verify changes**: After making edits, consider reading the file again or running \
tests
4. **Be autonomous**: Use tools proactively to gather information and make changes
5. **Explain your actions**: Provide context around your tool usage so the user \
understands what you're doing

## Example Interaction

User: "Add error handling to the main function"

You might respond:
Let me first read the main function to see the current implementation.

<tool_use>
<tool_name>search_code</tool_name>
<parameters>
<pattern>def main</pattern>
<glob>*.py</glob>
</parameters>
</tool_use>

After seeing the search results, I'll read the specific file and then make the necessary \
changes.

Remember: You can use tools without asking for permission. The user expects you to be \
autonomous and proactive in using these tools to accomplish tasks efficiently.
"""


def format_tool_result_for_llm(result: ToolResult) -> str:
    """Format a tool result for inclusion in the LLM context.

    Args:
        result: The ToolResult to format

    Returns:
        Formatted string for LLM consumption
    """
    if result.success:
        return f"""<tool_result>
<tool_name>{result.tool_name}</tool_name>
<status>success</status>
<output>
{result.output}
</output>
</tool_result>"""
    else:
        error_msg = result.error or "Unknown error"
        return f"""<tool_result>
<tool_name>{result.tool_name}</tool_name>
<status>error</status>
<error>
{error_msg}
</error>
</tool_result>"""
