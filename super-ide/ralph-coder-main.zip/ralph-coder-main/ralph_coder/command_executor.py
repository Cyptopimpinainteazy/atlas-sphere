"""Command execution for running shell commands."""

import subprocess
from dataclasses import dataclass
from pathlib import Path


class CommandExecutionError(Exception):
    """Base exception for command execution errors."""

    pass


class CommandTimeoutError(CommandExecutionError):
    """Raised when a command exceeds the timeout."""

    pass


class CommandFailedError(CommandExecutionError):
    """Raised when a command exits with non-zero status."""

    pass


@dataclass
class CommandResult:
    """Container for command execution results.

    Attributes:
        command: The command that was executed
        stdout: Standard output from the command
        stderr: Standard error from the command
        exit_code: Exit code (0 = success, non-zero = failure)
        timed_out: Whether the command timed out
        working_dir: Directory where command was executed
    """

    command: str
    stdout: str
    stderr: str
    exit_code: int
    timed_out: bool
    working_dir: Path


class CommandExecutor:
    """Handles execution of shell commands with safety checks."""

    def __init__(
        self, working_dir: Path | None = None, default_timeout: int = 60
    ) -> None:
        """Initialize CommandExecutor.

        Args:
            working_dir: Directory to execute commands in (default: current directory)
            default_timeout: Default timeout in seconds for command execution
        """
        self.working_dir = working_dir if working_dir else Path.cwd()
        self.default_timeout = default_timeout

    def execute(
        self, command: str, timeout: int | None = None, shell: bool = True
    ) -> CommandResult:
        """Execute a shell command.

        Args:
            command: The command to execute
            timeout: Timeout in seconds (default: use default_timeout)
            shell: Whether to execute through the shell (default: True)

        Returns:
            CommandResult object containing execution results

        Raises:
            CommandTimeoutError: If the command exceeds the timeout
            CommandFailedError: If the command exits with non-zero status
        """
        if timeout is None:
            timeout = self.default_timeout

        timed_out = False
        try:
            # Execute the command
            result = subprocess.run(
                command,
                shell=shell,
                cwd=self.working_dir,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            stdout = result.stdout
            stderr = result.stderr
            exit_code = result.returncode

        except subprocess.TimeoutExpired as e:
            # Handle timeout
            timed_out = True
            stdout = e.stdout.decode() if e.stdout else ""
            stderr = e.stderr.decode() if e.stderr else ""
            exit_code = -1

            raise CommandTimeoutError(
                f"Command timed out after {timeout} seconds: {command}"
            )

        # Create result object
        cmd_result = CommandResult(
            command=command,
            stdout=stdout,
            stderr=stderr,
            exit_code=exit_code,
            timed_out=timed_out,
            working_dir=self.working_dir,
        )

        # Check for non-zero exit code
        if exit_code != 0:
            raise CommandFailedError(
                f"Command failed with exit code {exit_code}: {command}"
            )

        return cmd_result

    def execute_safe(
        self, command: str, timeout: int | None = None, shell: bool = True
    ) -> CommandResult:
        """Execute a command without raising exceptions for failures.

        This variant always returns a CommandResult, even for failures.

        Args:
            command: The command to execute
            timeout: Timeout in seconds (default: use default_timeout)
            shell: Whether to execute through the shell (default: True)

        Returns:
            CommandResult object containing execution results
        """
        if timeout is None:
            timeout = self.default_timeout

        timed_out = False
        try:
            # Execute the command
            result = subprocess.run(
                command,
                shell=shell,
                cwd=self.working_dir,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            stdout = result.stdout
            stderr = result.stderr
            exit_code = result.returncode

        except subprocess.TimeoutExpired as e:
            # Handle timeout
            timed_out = True
            stdout = e.stdout.decode() if e.stdout else ""
            stderr = e.stderr.decode() if e.stderr else ""
            exit_code = -1

        # Create and return result object
        return CommandResult(
            command=command,
            stdout=stdout,
            stderr=stderr,
            exit_code=exit_code,
            timed_out=timed_out,
            working_dir=self.working_dir,
        )
