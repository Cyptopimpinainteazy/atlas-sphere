"""REPL (Read-Eval-Print Loop) interface for Ralph Coder."""

import re
from pathlib import Path
from typing import Any

from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.key_binding.key_processor import KeyPressEvent
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.spinner import Spinner
from rich.syntax import Syntax

from ralph_coder.command_executor import (
    CommandExecutor,
    CommandResult,
)
from ralph_coder.context_manager import ContextManager
from ralph_coder.file_editor import (
    EditPreview,
    FileEditError,
    FileEditor,
    WritePermissionError,
)
from ralph_coder.file_operations import FileOperationError, FileReader
from ralph_coder.search import CodeSearcher, RipgrepNotFoundError, SearchError
from ralph_coder.session import SessionConfig
from ralph_coder.tools import (
    ToolCallParser,
    ToolResult,
    format_tool_result_for_llm,
    get_system_prompt,
)


class REPL:
    """Interactive REPL for conversing with the coding assistant."""

    def __init__(self, session: SessionConfig, enable_tools: bool = True) -> None:
        """Initialize REPL with session configuration.

        Args:
            session: Session configuration containing client and model info
            enable_tools: Whether to enable autonomous tool calling (default: True)
        """
        self.session = session
        self.console = Console()
        self.conversation_history: list[dict[str, Any]] = []
        self.running = True
        self.file_reader = FileReader()
        self.file_editor = FileEditor()
        self.command_executor = CommandExecutor()
        self.enable_tools = enable_tools
        self.tool_parser = ToolCallParser()
        self.context_manager = ContextManager()

        # Initialize code searcher (may be None if ripgrep not available)
        try:
            self.code_searcher: CodeSearcher | None = CodeSearcher()
        except RipgrepNotFoundError:
            self.code_searcher = None
            self.console.print(
                "[yellow]Warning: ripgrep not found. "
                "Search functionality will be disabled.[/yellow]"
            )

        # Add system prompt to conversation history if tools are enabled
        if self.enable_tools:
            self.conversation_history.append({
                "role": "system",
                "content": get_system_prompt()
            })

    def display_help(self) -> None:
        """Display help message with available commands."""
        help_text = """
## Available Commands

- `/help` - Show this help message
- `/exit` or `/quit` - Exit the REPL
- `/clear` - Clear conversation history
- `/stats` - Show conversation context statistics
- `/model [name]` - Switch to a different model (or show current model if no name provided)
- `/read <file_path>` - Read and display a file from the codebase
- `/search <pattern> [--glob <pattern>] [-i]` - Search for a pattern in files
  (use -i for case-insensitive)
- `/write <file_path>` - Write or overwrite a file (multi-line input, end with blank line)
- `/replace <file_path> <search> <replace>` - Replace text in a file
- `/exec <command>` - Execute a shell command (requires confirmation)

## Usage

Type your questions or requests and press Enter twice to submit (blank line).
The agent will respond with assistance, and you can continue the conversation.

You can also ask the agent to read files by mentioning them naturally
(e.g., "read src/main.py").

You can search for code patterns naturally (e.g., "search for def main"
or "find files containing TODO").
        """
        self.console.print(Markdown(help_text))

    def display_welcome(self) -> None:
        """Display welcome message."""
        self.console.print("\n[bold cyan]Ralph Coder - Interactive Coding Assistant[/bold cyan]")
        self.console.print(f"[dim]Model: {self.session.model} | Host: {self.session.host}[/dim]")
        self.console.print("[dim]Type /help for commands, /exit to quit[/dim]")
        self.console.print("[dim]💡 Tip: Press Enter to send, Alt+Enter for new line[/dim]\n")

    def get_multiline_input(self) -> str:
        """Get multi-line input from user.

        Enter submits, Alt+Enter adds new line.

        Returns:
            User input as a single string
        """
        # Create custom key bindings
        bindings = KeyBindings()

        @bindings.add('enter')
        def _(event: KeyPressEvent) -> None:
            """Enter key submits the input."""
            event.current_buffer.validate_and_handle()

        @bindings.add('escape', 'enter')  # Alt+Enter (Meta+Enter)
        def _(event: KeyPressEvent) -> None:
            """Alt+Enter adds a newline."""
            event.current_buffer.insert_text('\n')

        # Create a prompt session with multiline support and custom bindings
        session: PromptSession[str] = PromptSession(
            message=HTML('<ansigreen><b>You:</b></ansigreen> '),
            multiline=True,
            key_bindings=bindings
        )

        try:
            user_input = session.prompt()
            return user_input
        except EOFError:
            # Handle Ctrl+D
            self.running = False
            return ""
        except KeyboardInterrupt:
            # Handle Ctrl+C
            self.console.print("\n[yellow]Use /exit to quit[/yellow]")
            return ""

    def handle_command(self, command: str) -> bool:
        """Handle REPL commands.

        Args:
            command: Command string (including leading /)

        Returns:
            True if command was handled, False otherwise
        """
        parts = command.split(maxsplit=1)
        cmd = parts[0].lower()

        if cmd in ["/exit", "/quit"]:
            self.console.print("[cyan]Goodbye![/cyan]")
            self.running = False
            return True

        if cmd == "/help":
            self.display_help()
            return True

        if cmd == "/clear":
            self.conversation_history.clear()
            # Re-add system prompt if tools are enabled
            if self.enable_tools:
                self.conversation_history.append({
                    "role": "system",
                    "content": get_system_prompt()
                })
            self.console.print("[cyan]Conversation history cleared.[/cyan]")
            return True

        if cmd == "/stats":
            stats = self.context_manager.get_context_stats(self.conversation_history)
            stats_display = self.context_manager.format_stats_display(stats)
            self.console.print(Markdown(stats_display))
            return True

        if cmd == "/model":
            if len(parts) > 1:
                new_model = parts[1].strip()
                # Check if model is available
                if self.session.client.is_model_available(new_model):
                    self.session.model = new_model
                    self.console.print(f"[green]Switched to model: {new_model}[/green]")
                else:
                    self.console.print(f"[red]Model '{new_model}' not found.[/red]")
                    available_models = self.session.client.get_available_models()
                    self.console.print("[yellow]Available models:[/yellow]")
                    for model in available_models:
                        self.console.print(f"  - {model}")
            else:
                self.console.print(f"[cyan]Current model: {self.session.model}[/cyan]")
            return True

        if cmd == "/read":
            if len(parts) > 1:
                file_path = parts[1].strip()
                self.read_and_display_file(file_path)
            else:
                self.console.print("[red]Usage: /read <file_path>[/red]")
            return True

        if cmd == "/search":
            if len(parts) > 1:
                args_str = parts[1].strip()
                self.search_and_display(args_str)
            else:
                self.console.print("[red]Usage: /search <pattern> [--glob <pattern>] [-i][/red]")
                self.console.print("[dim]Examples:[/dim]")
                self.console.print("[dim]  /search 'def main'[/dim]")
                self.console.print("[dim]  /search 'TODO' --glob '*.py'[/dim]")
                self.console.print("[dim]  /search 'error' -i[/dim]")
            return True

        if cmd == "/write":
            if len(parts) > 1:
                file_path = parts[1].strip()
                self.write_file_interactive(file_path)
            else:
                self.console.print("[red]Usage: /write <file_path>[/red]")
                self.console.print("[dim]You will be prompted to enter the file content.[/dim]")
            return True

        if cmd == "/replace":
            if len(parts) > 1:
                self.replace_in_file_interactive(parts[1])
            else:
                self.console.print("[red]Usage: /replace <file_path> <search> <replace>[/red]")
                self.console.print("[dim]Examples:[/dim]")
                self.console.print("[dim]  /replace main.py 'old_text' 'new_text'[/dim]")
                self.console.print(
                    "[dim]  /replace src/config.py 'DEBUG = False' 'DEBUG = True'[/dim]"
                )
            return True

        if cmd == "/exec":
            if len(parts) > 1:
                command = parts[1].strip()
                self.execute_command_interactive(command)
            else:
                self.console.print("[red]Usage: /exec <command>[/red]")
                self.console.print("[dim]Examples:[/dim]")
                self.console.print("[dim]  /exec ls -la[/dim]")
                self.console.print("[dim]  /exec poetry run pytest[/dim]")
                self.console.print("[dim]  /exec git status[/dim]")
            return True

        # Unknown command
        self.console.print(f"[red]Unknown command: {cmd}[/red]")
        self.console.print("[dim]Type /help for available commands[/dim]")
        return True

    def read_and_display_file(self, file_path: str, add_to_context: bool = True) -> None:
        """Read a file and display its contents.

        Args:
            file_path: Path to the file to read
            add_to_context: Whether to add the file content to conversation context
        """
        try:
            file_content = self.file_reader.read_file(file_path)

            # Display file header
            self.console.print(f"\n[bold cyan]File:[/bold cyan] {file_content.path}")
            self.console.print(f"[dim]Lines: {file_content.line_count}", end="")
            if file_content.truncated:
                self.console.print(
                    f" (truncated at {self.file_reader.max_lines} lines)",
                    style="yellow"
                )
            else:
                self.console.print()

            # Display file content with syntax highlighting
            # Try to infer lexer from file extension
            lexer = self._infer_lexer(file_content.path.suffix)
            syntax = Syntax(
                file_content.content,
                lexer,
                theme="monokai",
                line_numbers=True,
                word_wrap=False
            )
            self.console.print(syntax)
            self.console.print()

            # Add to conversation context if requested
            if add_to_context:
                context_message = (
                    f"[File: {file_content.path}]\n"
                    f"```\n{file_content.content}\n```"
                )
                self.conversation_history.append({
                    "role": "user",
                    "content": context_message
                })

        except FileNotFoundError:
            self.console.print(f"[red]Error: File not found: {file_path}[/red]")
        except IsADirectoryError:
            self.console.print(f"[red]Error: Path is a directory: {file_path}[/red]")
        except PermissionError:
            self.console.print(f"[red]Error: Permission denied: {file_path}[/red]")
        except FileOperationError as e:
            self.console.print(f"[red]Error reading file: {e}[/red]")

    def search_and_display(self, args_str: str, add_to_context: bool = True) -> None:
        """Search for a pattern in files and display results.

        Args:
            args_str: Search arguments (pattern and optional flags)
            add_to_context: Whether to add search results to conversation context
        """
        if self.code_searcher is None:
            self.console.print(
                "[red]Search functionality is not available (ripgrep not installed)[/red]"
            )
            return

        # Parse search arguments
        import shlex

        try:
            args = shlex.split(args_str)
        except ValueError as e:
            self.console.print(f"[red]Error parsing search arguments: {e}[/red]")
            return

        if not args:
            self.console.print("[red]Please provide a search pattern[/red]")
            return

        # Extract pattern and flags
        pattern = args[0]
        glob_pattern: str | None = None
        case_sensitive = True  # Default to case-sensitive

        # Parse optional flags
        i = 1
        while i < len(args):
            arg = args[i]
            if arg == "--glob" and i + 1 < len(args):
                glob_pattern = args[i + 1]
                i += 2
            elif arg == "-i" or arg == "--ignore-case":
                case_sensitive = False
                i += 1
            else:
                self.console.print(f"[yellow]Warning: Unknown flag '{arg}' ignored[/yellow]")
                i += 1

        # Perform search
        try:
            result = self.code_searcher.search(
                pattern=pattern,
                glob=glob_pattern,
                case_sensitive=case_sensitive
            )

            # Display search header
            self.console.print("\n[bold cyan]Search Results[/bold cyan]")
            self.console.print(f"[dim]Pattern: {pattern}", end="")
            if glob_pattern:
                self.console.print(f" | Glob: {glob_pattern}", end="")
            if not case_sensitive:
                self.console.print(" | Case-insensitive", end="")
            self.console.print("[/dim]")

            # Display matches
            if not result.matches:
                self.console.print("[yellow]No matches found[/yellow]\n")
                return

            self.console.print(f"[dim]Found {result.total_matches} match(es)", end="")
            if result.truncated:
                self.console.print(
                    f" (showing first {self.code_searcher.max_results})",
                    style="yellow"
                )
            else:
                self.console.print()

            self.console.print()

            # Group matches by file for better readability
            current_file: Path | None = None
            for match in result.matches:
                if match.file_path != current_file:
                    current_file = match.file_path
                    self.console.print(f"\n[bold green]{match.file_path}[/bold green]")

                # Display the match with line number
                self.console.print(
                    f"  [cyan]{match.line_number:4d}[/cyan]: {match.line_content}"
                )

            self.console.print()

            # Add to conversation context if requested
            if add_to_context:
                context_message = f"[Search results for pattern '{pattern}']\n"
                if glob_pattern:
                    context_message += f"[Glob: {glob_pattern}]\n"
                context_message += f"Found {result.total_matches} match(es):\n\n"

                for match in result.matches:
                    context_message += (
                        f"{match.file_path}:{match.line_number}: "
                        f"{match.line_content}\n"
                    )

                self.conversation_history.append({
                    "role": "user",
                    "content": context_message
                })

        except SearchError as e:
            self.console.print(f"[red]Search error: {e}[/red]")

    def write_file_interactive(self, file_path: str) -> None:
        """Interactively write content to a file with confirmation.

        Args:
            file_path: Path to the file to write
        """
        # Get content from user
        self.console.print("\n[bold cyan]Enter file content[/bold cyan]")
        self.console.print("[dim](Press Enter twice on a blank line to finish)[/dim]\n")

        lines: list[str] = []
        blank_count = 0

        while True:
            try:
                line = input("... ")
                if line == "":
                    blank_count += 1
                    if blank_count >= 2:
                        # Two consecutive blank lines signals end
                        # Remove the last blank line from the content
                        if lines and lines[-1] == "":
                            lines.pop()
                        break
                    lines.append(line)
                else:
                    blank_count = 0
                    lines.append(line)
            except (EOFError, KeyboardInterrupt):
                self.console.print("\n[yellow]Cancelled[/yellow]")
                return

        content = "\n".join(lines)

        # Preview the edit
        try:
            preview = self.file_editor.preview_write(file_path, content)
            self._display_and_confirm_edit(preview)
        except IsADirectoryError:
            self.console.print(f"[red]Error: Path is a directory: {file_path}[/red]")
        except FileEditError as e:
            self.console.print(f"[red]Error: {e}[/red]")

    def replace_in_file_interactive(self, args: str) -> None:
        """Interactively replace text in a file with confirmation.

        Args:
            args: Arguments string containing file_path, search, and replace
        """
        import shlex

        # Parse arguments
        try:
            parts = shlex.split(args)
        except ValueError as e:
            self.console.print(f"[red]Error parsing arguments: {e}[/red]")
            return

        if len(parts) < 3:
            self.console.print("[red]Usage: /replace <file_path> <search> <replace>[/red]")
            return

        file_path = parts[0]
        search = parts[1]
        replace = parts[2]

        # Preview the edit
        try:
            preview = self.file_editor.preview_replace(file_path, search, replace)
            self._display_and_confirm_edit(preview)
        except FileNotFoundError:
            self.console.print(f"[red]Error: File not found: {file_path}[/red]")
        except IsADirectoryError:
            self.console.print(f"[red]Error: Path is a directory: {file_path}[/red]")
        except FileEditError as e:
            self.console.print(f"[red]Error: {e}[/red]")

    def _display_and_confirm_edit(self, preview: EditPreview) -> None:
        """Display an edit preview and ask for user confirmation.

        Args:
            preview: EditPreview object to display
        """
        # Display header
        if preview.is_new_file:
            self.console.print(f"\n[bold cyan]Creating new file:[/bold cyan] {preview.file_path}")
        else:
            self.console.print(f"\n[bold cyan]Editing file:[/bold cyan] {preview.file_path}")

        # Display diff
        if preview.diff:
            self.console.print("\n[bold]Diff Preview:[/bold]")
            syntax = Syntax(
                preview.diff,
                "diff",
                theme="monokai",
                word_wrap=False
            )
            self.console.print(syntax)
        else:
            self.console.print("\n[yellow]No changes to apply[/yellow]")
            return

        # Ask for confirmation
        self.console.print()
        try:
            prompt = "[bold yellow]Apply these changes? (y/n):[/bold yellow] "
            response = input(prompt).strip().lower()
        except (EOFError, KeyboardInterrupt):
            self.console.print("\n[yellow]Cancelled[/yellow]")
            return

        if response not in ["y", "yes"]:
            self.console.print("[yellow]Edit cancelled[/yellow]")
            return

        # Apply the edit
        try:
            backup_path = self.file_editor.apply_edit(preview, create_backup=True)

            if preview.is_new_file:
                self.console.print(f"[green]✓ Created file: {preview.file_path}[/green]")
            else:
                self.console.print(f"[green]✓ Updated file: {preview.file_path}[/green]")
                if backup_path:
                    self.console.print(f"[dim]Backup created: {backup_path}[/dim]")

        except WritePermissionError:
            self.console.print(f"[red]Error: Permission denied: {preview.file_path}[/red]")
        except FileEditError as e:
            self.console.print(f"[red]Error applying edit: {e}[/red]")

    def execute_command_interactive(self, command: str, timeout: int | None = None) -> None:
        """Interactively execute a shell command with confirmation.

        Args:
            command: The command to execute
            timeout: Optional timeout in seconds (uses default if not specified)
        """
        # Display the command and ask for confirmation
        self.console.print(f"\n[bold cyan]Execute command:[/bold cyan] {command}")
        self.console.print(
            f"[dim]Working directory: {self.command_executor.working_dir}[/dim]"
        )

        # Ask for confirmation
        try:
            prompt = "[bold yellow]Execute this command? (y/n):[/bold yellow] "
            response = input(prompt).strip().lower()
        except (EOFError, KeyboardInterrupt):
            self.console.print("\n[yellow]Cancelled[/yellow]")
            return

        if response not in ["y", "yes"]:
            self.console.print("[yellow]Command cancelled[/yellow]")
            return

        # Execute the command (using safe variant to handle failures gracefully)
        self.console.print("\n[cyan]Running command...[/cyan]")
        result = self.command_executor.execute_safe(command, timeout=timeout)

        # Display results
        self._display_command_result(result)

    def _display_command_result(self, result: CommandResult) -> None:
        """Display the results of a command execution.

        Args:
            result: CommandResult object to display
        """
        # Display stdout if present
        if result.stdout:
            self.console.print("\n[bold green]Output:[/bold green]")
            self.console.print(result.stdout)

        # Display stderr if present
        if result.stderr:
            self.console.print("\n[bold yellow]Error Output:[/bold yellow]")
            self.console.print(result.stderr)

        # Display exit code
        if result.timed_out:
            self.console.print(
                f"\n[bold red]Command timed out[/bold red] (exit code: {result.exit_code})"
            )
        elif result.exit_code == 0:
            self.console.print("\n[bold green]Success[/bold green] (exit code: 0)")
        else:
            self.console.print(
                f"\n[bold red]Failed[/bold red] (exit code: {result.exit_code})"
            )

        # Add results to conversation context
        context_message = f"[Command executed: {result.command}]\n"
        context_message += f"[Exit code: {result.exit_code}]\n"
        if result.stdout:
            context_message += f"[Output]\n{result.stdout}\n"
        if result.stderr:
            context_message += f"[Error output]\n{result.stderr}\n"

        self.conversation_history.append({"role": "user", "content": context_message})

    def _infer_lexer(self, suffix: str) -> str:
        """Infer syntax lexer from file extension.

        Args:
            suffix: File extension (e.g., '.py', '.js')

        Returns:
            Lexer name for syntax highlighting
        """
        lexer_map = {
            ".py": "python",
            ".js": "javascript",
            ".ts": "typescript",
            ".jsx": "jsx",
            ".tsx": "tsx",
            ".java": "java",
            ".c": "c",
            ".cpp": "cpp",
            ".h": "c",
            ".hpp": "cpp",
            ".rs": "rust",
            ".go": "go",
            ".rb": "ruby",
            ".php": "php",
            ".sh": "bash",
            ".bash": "bash",
            ".zsh": "bash",
            ".html": "html",
            ".css": "css",
            ".json": "json",
            ".yaml": "yaml",
            ".yml": "yaml",
            ".toml": "toml",
            ".xml": "xml",
            ".md": "markdown",
            ".sql": "sql",
        }
        return lexer_map.get(suffix.lower(), "text")

    def _execute_tool(self, tool_name: str, parameters: dict[str, str]) -> ToolResult:
        """Execute a single tool call.

        Args:
            tool_name: Name of the tool to execute
            parameters: Parameters for the tool

        Returns:
            ToolResult with execution status and output
        """
        try:
            if tool_name == "read_file":
                return self._tool_read_file(parameters)
            elif tool_name == "search_code":
                return self._tool_search_code(parameters)
            elif tool_name == "write_file":
                return self._tool_write_file(parameters)
            elif tool_name == "replace_in_file":
                return self._tool_replace_in_file(parameters)
            elif tool_name == "execute_command":
                return self._tool_execute_command(parameters)
            else:
                return ToolResult(
                    tool_name=tool_name,
                    success=False,
                    output="",
                    error=f"Unknown tool: {tool_name}"
                )
        except Exception as e:
            return ToolResult(
                tool_name=tool_name,
                success=False,
                output="",
                error=str(e)
            )

    def _tool_read_file(self, parameters: dict[str, str]) -> ToolResult:
        """Execute read_file tool.

        Args:
            parameters: Tool parameters

        Returns:
            ToolResult with file contents
        """
        file_path = parameters.get("file_path", "")
        if not file_path:
            return ToolResult(
                tool_name="read_file",
                success=False,
                output="",
                error="Missing required parameter: file_path"
            )

        try:
            file_content = self.file_reader.read_file(file_path)
            output = f"File: {file_content.path}\n"
            output += f"Lines: {file_content.line_count}\n"
            if file_content.truncated:
                output += f"(Truncated at {self.file_reader.max_lines} lines)\n"
            output += f"\n{file_content.content}"

            # Display to user
            self.console.print(f"\n[dim]Tool: read_file → {file_path}[/dim]")

            return ToolResult(
                tool_name="read_file",
                success=True,
                output=output
            )
        except (FileNotFoundError, IsADirectoryError, PermissionError) as e:
            return ToolResult(
                tool_name="read_file",
                success=False,
                output="",
                error=str(e)
            )

    def _tool_search_code(self, parameters: dict[str, str]) -> ToolResult:
        """Execute search_code tool.

        Args:
            parameters: Tool parameters

        Returns:
            ToolResult with search results
        """
        if self.code_searcher is None:
            return ToolResult(
                tool_name="search_code",
                success=False,
                output="",
                error="Search functionality not available (ripgrep not installed)"
            )

        pattern = parameters.get("pattern", "")
        if not pattern:
            return ToolResult(
                tool_name="search_code",
                success=False,
                output="",
                error="Missing required parameter: pattern"
            )

        glob_pattern = parameters.get("glob")
        case_sensitive = parameters.get("case_sensitive", "true").lower() == "true"

        try:
            result = self.code_searcher.search(
                pattern=pattern,
                glob=glob_pattern,
                case_sensitive=case_sensitive
            )

            output = f"Search pattern: {pattern}\n"
            if glob_pattern:
                output += f"Glob: {glob_pattern}\n"
            output += f"Found {result.total_matches} match(es)\n\n"

            for match in result.matches:
                output += f"{match.file_path}:{match.line_number}: {match.line_content}\n"

            # Display to user
            self.console.print(f"\n[dim]Tool: search_code → '{pattern}'[/dim]")

            return ToolResult(
                tool_name="search_code",
                success=True,
                output=output
            )
        except Exception as e:
            return ToolResult(
                tool_name="search_code",
                success=False,
                output="",
                error=str(e)
            )

    def _tool_write_file(self, parameters: dict[str, str]) -> ToolResult:
        """Execute write_file tool.

        Args:
            parameters: Tool parameters

        Returns:
            ToolResult with write status
        """
        file_path = parameters.get("file_path", "")
        content = parameters.get("content", "")

        if not file_path:
            return ToolResult(
                tool_name="write_file",
                success=False,
                output="",
                error="Missing required parameter: file_path"
            )

        try:
            # Preview the edit
            preview = self.file_editor.preview_write(file_path, content)

            # Display preview to user
            self.console.print(f"\n[dim]Tool: write_file → {file_path}[/dim]")
            if preview.is_new_file:
                self.console.print(f"[yellow]Creating new file: {file_path}[/yellow]")
            else:
                self.console.print(f"[yellow]Overwriting file: {file_path}[/yellow]")

            # Apply the edit automatically (autonomous mode)
            backup_path = self.file_editor.apply_edit(preview, create_backup=True)

            output = f"File written: {file_path}\n"
            if backup_path:
                output += f"Backup created: {backup_path}\n"

            self.console.print(f"[green]✓ File written: {file_path}[/green]")

            return ToolResult(
                tool_name="write_file",
                success=True,
                output=output
            )
        except Exception as e:
            return ToolResult(
                tool_name="write_file",
                success=False,
                output="",
                error=str(e)
            )

    def _tool_replace_in_file(self, parameters: dict[str, str]) -> ToolResult:
        """Execute replace_in_file tool.

        Args:
            parameters: Tool parameters

        Returns:
            ToolResult with replacement status
        """
        file_path = parameters.get("file_path", "")
        search = parameters.get("search", "")
        replace = parameters.get("replace", "")

        if not file_path or not search:
            return ToolResult(
                tool_name="replace_in_file",
                success=False,
                output="",
                error="Missing required parameters: file_path, search"
            )

        try:
            # Preview the edit
            preview = self.file_editor.preview_replace(file_path, search, replace)

            # Display preview to user
            self.console.print(f"\n[dim]Tool: replace_in_file → {file_path}[/dim]")
            self.console.print(f"[yellow]Replacing '{search}' with '{replace}'[/yellow]")

            # Apply the edit automatically (autonomous mode)
            backup_path = self.file_editor.apply_edit(preview, create_backup=True)

            output = f"Replaced in file: {file_path}\n"
            if backup_path:
                output += f"Backup created: {backup_path}\n"

            self.console.print(f"[green]✓ File updated: {file_path}[/green]")

            return ToolResult(
                tool_name="replace_in_file",
                success=True,
                output=output
            )
        except Exception as e:
            return ToolResult(
                tool_name="replace_in_file",
                success=False,
                output="",
                error=str(e)
            )

    def _tool_execute_command(self, parameters: dict[str, str]) -> ToolResult:
        """Execute execute_command tool.

        Args:
            parameters: Tool parameters

        Returns:
            ToolResult with command output
        """
        command = parameters.get("command", "")
        if not command:
            return ToolResult(
                tool_name="execute_command",
                success=False,
                output="",
                error="Missing required parameter: command"
            )

        try:
            # Display to user
            self.console.print(f"\n[dim]Tool: execute_command → {command}[/dim]")

            # Execute the command
            result = self.command_executor.execute_safe(command)

            output = f"Command: {command}\n"
            output += f"Exit code: {result.exit_code}\n"
            if result.stdout:
                output += f"Output:\n{result.stdout}\n"
            if result.stderr:
                output += f"Error output:\n{result.stderr}\n"

            # Display status
            if result.exit_code == 0:
                self.console.print("[green]✓ Command succeeded[/green]")
            else:
                self.console.print(f"[red]✗ Command failed (exit code: {result.exit_code})[/red]")

            return ToolResult(
                tool_name="execute_command",
                success=result.exit_code == 0,
                output=output,
                error=result.stderr if result.exit_code != 0 else None
            )
        except Exception as e:
            return ToolResult(
                tool_name="execute_command",
                success=False,
                output="",
                error=str(e)
            )

    def chat(self, user_message: str) -> None:
        """Send message to LLM and display response.

        Args:
            user_message: User's message
        """
        # DEBUG to fileimport re

        # If tools are not enabled, use the old simple pattern matching
        if not self.enable_tools:
            # Check if the user is asking to read a file
            # Simple pattern matching for common file reading requests
            read_patterns = [
                r"(?:read|show|display|open)\s+(?:the\s+)?file\s+['\"]?([^\s'\"]+)",
                r"(?:read|show|display|open)\s+['\"]?([^\s'\"]+\.[\w]+)",
            ]

            for pattern in read_patterns:
                match = re.search(pattern, user_message.lower())
                if match:
                    # Extract the file path (from the original, not lowercased message)
                    # Re-run the pattern on the original to get proper casing
                    original_match = re.search(pattern, user_message, re.IGNORECASE)
                    if original_match:
                        file_path = original_match.group(1)
                        # Try to read the file
                        self.read_and_display_file(file_path)
                        # Don't send to LLM if we successfully handled the file read
                        return

            # Check if the user is asking to search for something
            # Patterns for search requests
            search_patterns = [
                r"(?:search|find|grep|look)\s+(?:for\s+)?['\"]([^'\"]+)['\"]",  # Quoted patterns
                r"(?:search|find|grep|look)\s+(?:for\s+)?(?:files?\s+)?(?:containing|with)\s+['\"]?([^\s'\"]+)",
            ]

            for pattern in search_patterns:
                match = re.search(pattern, user_message, re.IGNORECASE)
                if match:
                    search_pattern = match.group(1)
                    # Check for glob patterns in the message
                    glob_match = re.search(
                        r"in\s+['\"]?(\*\.[\w]+|[\*\w]+\.[\w]+)['\"]?",
                        user_message,
                        re.IGNORECASE
                    )
                    glob_pattern = glob_match.group(1) if glob_match else None

                    # Build search args
                    args = f"'{search_pattern}'"
                    if glob_pattern:
                        args += f" --glob '{glob_pattern}'"

                    # Perform the search
                    self.search_and_display(args)
                    # Don't send to LLM if we successfully handled the search
                    return

        # Add user message to history
        self.conversation_history.append({
            "role": "user",
            "content": user_message
        })

        # Check if context needs trimming
        if self.context_manager.should_trim_context(self.conversation_history):
            self.console.print(
                "[yellow]Note: Context approaching limit. Trimming older messages...[/yellow]"
            )
            self.conversation_history = self.context_manager.trim_context(
                self.conversation_history
            )
            # Show updated stats
            stats = self.context_manager.get_context_stats(self.conversation_history)
            self.console.print(
                f"[dim]Context trimmed to {stats.estimated_tokens:,} tokens "
                f"({stats.total_messages} messages)[/dim]\n"
            )

        # Autonomous tool calling loop
        max_iterations = 10  # Prevent infinite loops
        iteration = 0

        while iteration < max_iterations:
            iteration += 1

            # Display thinking indicator and get response
            try:
                with Live(
                    Spinner("dots", text="[cyan]Thinking...[/cyan]"),
                    console=self.console,
                    refresh_per_second=10
                ):
                    response = self.session.client.chat(
                        model=self.session.model,
                        messages=self.conversation_history,
                        stream=False
                    )

                # Extract assistant's response
                # Ollama returns ChatResponse object, not dict
                assistant_message = response.message.content or ""

                # Parse for tool calls if tools are enabled
                if self.enable_tools:
                    tool_calls, cleaned_response = self.tool_parser.parse_response(
                        assistant_message
                    )# If there are tool calls, execute them
                    if tool_calls:
                        # Add the assistant's message with tool calls to history
                        self.conversation_history.append({
                            "role": "assistant",
                            "content": assistant_message
                        })

                        # Display any text response before tool calls
                        if cleaned_response.strip():
                            self.console.print("\n[bold blue]Assistant:[/bold blue]")
                            self.console.print(Markdown(cleaned_response))

                        # Execute each tool call
                        tool_results: list[ToolResult] = []
                        for tool_call in tool_calls:
                            result = self._execute_tool(
                                tool_call.tool_name,
                                tool_call.parameters
                            )
                            tool_results.append(result)

                        # Format tool results for LLM
                        tool_results_message = "\n\n".join(
                            format_tool_result_for_llm(result)
                            for result in tool_results
                        )

                        # Add tool results to conversation history
                        self.conversation_history.append({
                            "role": "user",
                            "content": tool_results_message
                        })

                        # Continue the loop to let LLM process tool results
                        continue

                # No tool calls - this is the final response
                self.conversation_history.append({
                    "role": "assistant",
                    "content": assistant_message
                })

                # Display response with markdown rendering
                self.console.print("\n[bold blue]Assistant:[/bold blue]")
                self.console.print(Markdown(assistant_message))
                self.console.print()

                # Exit the loop - conversation turn is complete
                break

            except Exception as e:
                self.console.print(f"[red]Error: {e}[/red]")
                break

        if iteration >= max_iterations:
            self.console.print(
                "[yellow]Warning: Maximum tool call iterations reached. "
                "Ending conversation turn.[/yellow]"
            )

    def run(self) -> None:
        """Run the REPL loop."""
        self.display_welcome()

        while self.running:
            try:
                user_input = self.get_multiline_input()

                if not self.running:
                    # User pressed Ctrl+D
                    break

                # Skip empty input
                if not user_input.strip():
                    continue

                # Handle commands
                if user_input.startswith("/"):
                    self.handle_command(user_input)
                    continue

                # Send to LLM
                self.chat(user_input)

            except KeyboardInterrupt:
                self.console.print("\n[yellow]Use /exit to quit[/yellow]")
                continue
            except Exception as e:
                self.console.print(f"[red]Unexpected error: {e}[/red]")
                continue

        self.console.print()
