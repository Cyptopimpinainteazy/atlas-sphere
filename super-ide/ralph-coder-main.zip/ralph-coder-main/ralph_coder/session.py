"""Session configuration and state management."""

from dataclasses import dataclass

from ralph_coder.ollama_client import OllamaClientWrapper


@dataclass
class SessionConfig:
    """Configuration for a Ralph Coder session.

    Attributes:
        client: Ollama client wrapper instance
        model: Selected model name
        host: Ollama server endpoint
    """

    client: OllamaClientWrapper
    model: str
    host: str
