"""Command-line interface for Ralph Coder."""

from typing import Annotated

import typer
from rich.console import Console

from ralph_coder.ollama_client import ConnectionError as OllamaConnectionError
from ralph_coder.ollama_client import OllamaClientWrapper
from ralph_coder.repl import REPL
from ralph_coder.session import SessionConfig

app = typer.Typer(
    name="ralph-coder",
    help="Interactive coding assistant powered by local Ollama LLMs",
    add_completion=False,
)
console = Console()


def select_default_model(available_models: list[str]) -> str | None:
    """Select a sensible default model from available models.

    Prioritizes coding-focused models, then general purpose models.

    Args:
        available_models: List of available model names

    Returns:
        Default model name, or None if no suitable model found
    """
    if not available_models:
        return None

    # Preferred models in priority order
    preferred = [
        "deepseek-coder",
        "codellama",
        "llama3",
        "llama2",
        "mistral",
    ]

    # Check for preferred models (case-insensitive, allows version suffixes)
    for pref in preferred:
        for model in available_models:
            if model.lower().startswith(pref.lower()):
                return model

    # Fall back to first available model
    return available_models[0]


@app.command()
def main(
    model: Annotated[
        str | None,
        typer.Option(
            "--model",
            "-m",
            help="Ollama model to use (e.g., deepseek-coder, llama3)",
        ),
    ] = None,
    host: Annotated[
        str | None,
        typer.Option(
            "--host",
            help="Ollama server endpoint (default: http://localhost:11434)",
        ),
    ] = None,
    enable_tools: Annotated[
        bool,
        typer.Option(
            "--enable-tools/--no-tools",
            help="Enable autonomous tool calling (default: enabled)",
        ),
    ] = True,
) -> None:
    """Start the Ralph Coder interactive coding assistant."""
    try:
        # Initialize Ollama client
        client = OllamaClientWrapper(host=host)

        # Test connection and get available models
        console.print("[cyan]Connecting to Ollama...[/cyan]")
        available_models = client.get_available_models()

        if not available_models:
            console.print(
                "[red]No models found in Ollama. "
                "Please pull a model first (e.g., 'ollama pull llama3')[/red]"
            )
            raise typer.Exit(1)

        # Select model
        selected_model: str
        if model:
            if not client.is_model_available(model):
                console.print(f"[red]Model '{model}' not found.[/red]")
                console.print("[yellow]Available models:[/yellow]")
                for m in available_models:
                    console.print(f"  - {m}")
                raise typer.Exit(1)
            selected_model = model
        else:
            default = select_default_model(available_models)
            if default is None:
                console.print("[red]No suitable default model found.[/red]")
                raise typer.Exit(1)
            selected_model = default
            console.print(f"[dim]Using default model: {selected_model}[/dim]")

        # Create session config
        session = SessionConfig(
            client=client,
            model=selected_model,
            host=client.host,
        )

        # Display session info
        console.print(f"[green]✓ Connected to Ollama at {session.host}[/green]")
        console.print(f"[green]✓ Using model: {session.model}[/green]")
        console.print()

        # Display tool status
        if enable_tools:
            console.print("[green]✓ Autonomous tool calling enabled[/green]")
        else:
            console.print("[dim]Autonomous tool calling disabled[/dim]")

        # Start REPL
        repl = REPL(session, enable_tools=enable_tools)
        repl.run()

    except OllamaConnectionError as e:
        console.print(f"[red]Connection error: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
