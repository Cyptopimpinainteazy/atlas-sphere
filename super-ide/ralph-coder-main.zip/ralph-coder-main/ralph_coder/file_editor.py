"""File editing operations with diff preview and backup functionality."""

import difflib
import shutil
from dataclasses import dataclass
from pathlib import Path


class FileEditError(Exception):
    """Base exception for file editing errors."""

    pass


class WritePermissionError(FileEditError):
    """Raised when a file cannot be written due to permissions."""

    pass


@dataclass
class EditPreview:
    """Container for previewing file edits before applying.

    Attributes:
        file_path: Path to the file being edited
        original_content: Original file content (empty string for new files)
        new_content: New content that will be written
        is_new_file: Whether this is a new file creation
        diff: Unified diff showing the changes
    """

    file_path: Path
    original_content: str
    new_content: str
    is_new_file: bool
    diff: str


class FileEditor:
    """Handles file editing operations with safety checks and backups."""

    def __init__(self, working_dir: Path | None = None) -> None:
        """Initialize FileEditor.

        Args:
            working_dir: Base directory for resolving relative paths (default: current directory)
        """
        self.working_dir = working_dir if working_dir else Path.cwd()

    def resolve_path(self, file_path: str) -> Path:
        """Resolve a file path (relative or absolute) to an absolute Path.

        Args:
            file_path: File path as string

        Returns:
            Resolved absolute Path object
        """
        path = Path(file_path)
        if path.is_absolute():
            return path
        else:
            return (self.working_dir / path).resolve()

    def preview_write(self, file_path: str, content: str) -> EditPreview:
        """Preview writing content to a file.

        Args:
            file_path: Path to the file (relative or absolute)
            content: New content to write

        Returns:
            EditPreview object showing the proposed changes

        Raises:
            IsADirectoryError: If the path points to a directory
        """
        resolved_path = self.resolve_path(file_path)

        # Check if it's a directory
        if resolved_path.exists() and resolved_path.is_dir():
            raise IsADirectoryError(f"Path is a directory: {resolved_path}")

        # Check if file exists
        is_new_file = not resolved_path.exists()
        original_content = ""

        if not is_new_file:
            # Read existing content
            try:
                with open(resolved_path, encoding="utf-8") as f:
                    original_content = f.read()
            except UnicodeDecodeError:
                # If we can't decode as UTF-8, treat as binary (not supported for editing)
                raise FileEditError(
                    f"Cannot edit binary file: {resolved_path}"
                )
            except Exception as e:
                raise FileEditError(
                    f"Error reading file {resolved_path}: {e}"
                ) from e

        # Generate diff
        diff = self._generate_diff(
            resolved_path,
            original_content,
            content,
            is_new_file
        )

        return EditPreview(
            file_path=resolved_path,
            original_content=original_content,
            new_content=content,
            is_new_file=is_new_file,
            diff=diff,
        )

    def preview_replace(
        self, file_path: str, search: str, replace: str, count: int = -1
    ) -> EditPreview:
        """Preview replacing text in a file using search-and-replace.

        Args:
            file_path: Path to the file (relative or absolute)
            search: Text to search for
            replace: Text to replace with
            count: Maximum number of replacements (-1 for all occurrences)

        Returns:
            EditPreview object showing the proposed changes

        Raises:
            FileNotFoundError: If the file doesn't exist
            IsADirectoryError: If the path points to a directory
            FileEditError: If the search string is not found
        """
        resolved_path = self.resolve_path(file_path)

        # Check if file exists
        if not resolved_path.exists():
            raise FileNotFoundError(f"File not found: {resolved_path}")

        # Check if it's a directory
        if resolved_path.is_dir():
            raise IsADirectoryError(f"Path is a directory: {resolved_path}")

        # Read existing content
        try:
            with open(resolved_path, encoding="utf-8") as f:
                original_content = f.read()
        except UnicodeDecodeError:
            raise FileEditError(
                f"Cannot edit binary file: {resolved_path}"
            )
        except Exception as e:
            raise FileEditError(
                f"Error reading file {resolved_path}: {e}"
            ) from e

        # Check if search string exists
        if search not in original_content:
            raise FileEditError(
                f"Search string not found in {resolved_path}: '{search}'"
            )

        # Perform replacement
        new_content = original_content.replace(search, replace, count)

        # Generate diff
        diff = self._generate_diff(
            resolved_path,
            original_content,
            new_content,
            is_new_file=False
        )

        return EditPreview(
            file_path=resolved_path,
            original_content=original_content,
            new_content=new_content,
            is_new_file=False,
            diff=diff,
        )

    def apply_edit(self, preview: EditPreview, create_backup: bool = True) -> Path | None:
        """Apply an edit preview to disk.

        Args:
            preview: EditPreview object from preview_write or preview_replace
            create_backup: Whether to create a .bak backup of the original file

        Returns:
            Path to the backup file if created, None otherwise

        Raises:
            WritePermissionError: If the file cannot be written due to permissions
            FileEditError: If any other error occurs during writing
        """
        backup_path: Path | None = None

        # Create backup if requested and file exists
        if create_backup and not preview.is_new_file:
            backup_path = self._create_backup(preview.file_path)

        # Create parent directory if it doesn't exist
        preview.file_path.parent.mkdir(parents=True, exist_ok=True)

        # Write the new content
        try:
            with open(preview.file_path, "w", encoding="utf-8") as f:
                f.write(preview.new_content)
        except PermissionError as e:
            raise WritePermissionError(
                f"Permission denied: {preview.file_path}"
            ) from e
        except Exception as e:
            raise FileEditError(
                f"Error writing file {preview.file_path}: {e}"
            ) from e

        return backup_path

    def _create_backup(self, file_path: Path) -> Path:
        """Create a backup of a file with .bak extension.

        Args:
            file_path: Path to the file to back up

        Returns:
            Path to the backup file

        Raises:
            FileEditError: If backup creation fails
        """
        backup_path = file_path.with_suffix(file_path.suffix + ".bak")

        # If a .bak already exists, use .bak.1, .bak.2, etc.
        counter = 1
        while backup_path.exists():
            backup_path = file_path.with_suffix(f"{file_path.suffix}.bak.{counter}")
            counter += 1

        try:
            shutil.copy2(file_path, backup_path)
        except Exception as e:
            raise FileEditError(
                f"Failed to create backup: {e}"
            ) from e

        return backup_path

    def _generate_diff(
        self,
        file_path: Path,
        original: str,
        new: str,
        is_new_file: bool
    ) -> str:
        """Generate a unified diff between original and new content.

        Args:
            file_path: Path to the file being edited
            original: Original content
            new: New content
            is_new_file: Whether this is a new file

        Returns:
            Unified diff as a string
        """
        if is_new_file:
            # For new files, show all lines as additions
            new_lines = new.splitlines(keepends=True)
            diff_lines = difflib.unified_diff(
                [],
                new_lines,
                fromfile="/dev/null",
                tofile=str(file_path),
                lineterm=""
            )
        else:
            # For existing files, show the diff
            original_lines = original.splitlines(keepends=True)
            new_lines = new.splitlines(keepends=True)
            diff_lines = difflib.unified_diff(
                original_lines,
                new_lines,
                fromfile=f"a/{file_path.name}",
                tofile=f"b/{file_path.name}",
                lineterm=""
            )

        return "".join(diff_lines)
