"""File operations for reading and displaying code files."""

import os
from dataclasses import dataclass
from pathlib import Path


class FileOperationError(Exception):
    """Base exception for file operation errors."""

    pass


class FileTooLargeError(FileOperationError):
    """Raised when a file exceeds the size limit."""

    pass


@dataclass
class FileContent:
    """Container for file content and metadata.

    Attributes:
        path: Absolute path to the file
        content: File content as string
        line_count: Number of lines in the file
        truncated: Whether the content was truncated due to size limits
    """

    path: Path
    content: str
    line_count: int
    truncated: bool


class FileReader:
    """Handles reading files from the filesystem with safety checks."""

    def __init__(self, working_dir: Path | None = None, max_lines: int = 10000) -> None:
        """Initialize FileReader.

        Args:
            working_dir: Base directory for resolving relative paths (default: current directory)
            max_lines: Maximum number of lines to read from a file
        """
        self.working_dir = working_dir if working_dir else Path.cwd()
        self.max_lines = max_lines

    def resolve_path(self, file_path: str) -> Path:
        """Resolve a file path (relative or absolute) to an absolute Path.

        Args:
            file_path: File path as string

        Returns:
            Resolved absolute Path object
        """
        path = Path(file_path)
        if path.is_absolute():
            return path
        else:
            return (self.working_dir / path).resolve()

    def read_file(self, file_path: str) -> FileContent:
        """Read a file from the filesystem.

        Args:
            file_path: Path to the file (relative or absolute)

        Returns:
            FileContent object containing the file data

        Raises:
            FileNotFoundError: If the file doesn't exist
            PermissionError: If the file can't be read due to permissions
            IsADirectoryError: If the path points to a directory
            FileTooLargeError: If the file exceeds max_lines
        """
        resolved_path = self.resolve_path(file_path)

        # Check if file exists
        if not resolved_path.exists():
            raise FileNotFoundError(f"File not found: {resolved_path}")

        # Check if it's a directory
        if resolved_path.is_dir():
            raise IsADirectoryError(f"Path is a directory: {resolved_path}")

        # Check if we have read permission
        if not os.access(resolved_path, os.R_OK):
            raise PermissionError(f"Permission denied: {resolved_path}")

        # Read the file with line limit
        try:
            with open(resolved_path, encoding="utf-8") as f:
                lines = []
                truncated = False

                for i, line in enumerate(f, start=1):
                    if i > self.max_lines:
                        truncated = True
                        break
                    lines.append(line.rstrip("\n\r"))

                content = "\n".join(lines)
                line_count = len(lines)

                return FileContent(
                    path=resolved_path,
                    content=content,
                    line_count=line_count,
                    truncated=truncated,
                )

        except UnicodeDecodeError as e:
            raise FileOperationError(f"Unable to decode file as UTF-8: {resolved_path}") from e
        except Exception as e:
            raise FileOperationError(f"Error reading file {resolved_path}: {e}") from e
