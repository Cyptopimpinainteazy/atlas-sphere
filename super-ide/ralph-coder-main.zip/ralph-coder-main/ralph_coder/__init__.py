"""Ralph Coder - An open-source LLM coding agent."""

__version__ = "0.1.0"
