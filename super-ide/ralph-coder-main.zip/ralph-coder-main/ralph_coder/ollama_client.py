"""Ollama client for interacting with local LLM instances."""

import os
from collections.abc import Iterator, Mapping, Sequence
from typing import Any, Literal, overload

from dotenv import load_dotenv
from ollama import ChatResponse, Client


class OllamaClientError(Exception):
    """Base exception for Ollama client errors."""
    pass


class ConnectionError(OllamaClientError):
    """Raised when connection to Ollama server fails."""
    pass


class ModelNotFoundError(OllamaClientError):
    """Raised when requested model is not available."""
    pass


class OllamaClientWrapper:
    """Wrapper for Ollama client with configuration and error handling."""

    def __init__(self, host: str | None = None) -> None:
        """Initialize Ollama client.

        Args:
            host: Ollama server endpoint. Defaults to OLLAMA_HOST env var or http://localhost:11434
        """
        load_dotenv()

        default_host = "http://localhost:11434"
        self.host: str = host if host else (os.getenv("OLLAMA_HOST") or default_host)
        self.client = Client(host=self.host)
        self._available_models: list[str] | None = None

    def test_connection(self) -> bool:
        """Test connection to Ollama server.

        Returns:
            True if connection successful

        Raises:
            ConnectionError: If unable to connect to Ollama server
        """
        try:
            self.get_available_models()
            return True
        except Exception as e:
            raise ConnectionError(
                f"Failed to connect to Ollama at {self.host}. "
                f"Please ensure Ollama is running. Error: {str(e)}"
            ) from e

    def get_available_models(self) -> list[str]:
        """Get list of available models from Ollama.

        Returns:
            List of available model names

        Raises:
            ConnectionError: If unable to connect to Ollama server
        """
        try:
            response = self.client.list()
            # response is a ListResponse object with .models attribute
            # Filter out any None values (should never happen in practice)
            models = [model.model for model in response.models if model.model is not None]
            self._available_models = models
            return models
        except Exception as e:
            raise ConnectionError(
                f"Failed to retrieve models from Ollama at {self.host}. "
                f"Error: {str(e)}"
            ) from e

    def is_model_available(self, model_name: str) -> bool:
        """Check if a specific model is available.

        Args:
            model_name: Name of the model to check

        Returns:
            True if model is available, False otherwise
        """
        if self._available_models is None:
            self.get_available_models()

        if self._available_models is None:
            return False

        return model_name in self._available_models

    @overload
    def chat(
        self,
        model: str,
        messages: Sequence[Mapping[str, Any]],
        stream: Literal[False] = False
    ) -> ChatResponse: ...

    @overload
    def chat(
        self,
        model: str,
        messages: Sequence[Mapping[str, Any]],
        stream: Literal[True]
    ) -> Iterator[ChatResponse]: ...

    def chat(
        self,
        model: str,
        messages: Sequence[Mapping[str, Any]],
        stream: bool = False
    ) -> ChatResponse | Iterator[ChatResponse]:
        """Send chat request to Ollama.

        Args:
            model: Model name to use
            messages: List of message dicts with 'role' and 'content'
            stream: Whether to stream the response

        Returns:
            Response from Ollama (dict if stream=False, iterator if stream=True)

        Raises:
            ModelNotFoundError: If requested model is not available
            OllamaClientError: For other errors
        """
        if not self.is_model_available(model):
            available = ", ".join(self._available_models or [])
            raise ModelNotFoundError(
                f"Model '{model}' not found. Available models: {available}"
            )

        try:
            if stream:
                result: Iterator[ChatResponse] = self.client.chat(
                    model=model,
                    messages=messages,
                    stream=True
                )
                return result
            else:
                result_single: ChatResponse = self.client.chat(
                    model=model,
                    messages=messages,
                    stream=False
                )
                return result_single
        except Exception as e:
            raise OllamaClientError(f"Error during chat: {str(e)}") from e
