# Ralph Coder

An autonomous, interactive coding assistant powered by open-source LLMs running locally through Ollama. Ralph Coder provides intelligent code assistance, file operations, code search, and command execution—all from your terminal.

## Features

- **Interactive REPL**: Natural conversation interface with markdown rendering
- **File Operations**: Read, write, and edit files with diff previews and automatic backups
- **Code Search**: Fast code search using ripgrep with glob pattern support
- **Command Execution**: Run shell commands with output capture and timeout controls
- **Autonomous Mode**: LLM can use tools automatically to complete complex tasks
- **Context Management**: Automatic conversation trimming to stay within model limits
- **Model Selection**: Switch between different Ollama models on the fly

## Prerequisites

1. **Python 3.11+** - Ralph Coder requires Python 3.11 or later
2. **Ollama** - Install from [ollama.ai](https://ollama.ai/)
3. **ripgrep (optional)** - For code search functionality. Install via:
   - macOS: `brew install ripgrep`
   - Ubuntu/Debian: `apt install ripgrep`
   - Other: See [ripgrep installation](https://github.com/BurntSushi/ripgrep#installation)

### Recommended Models

Pull at least one of these models using Ollama:

```bash
# Recommended for coding tasks
ollama pull qwen3-coder

# Alternatives
ollama pull gpt-oss:120b-cloud # (cloud version)

```

To see available models:
```bash
ollama list
```

## Installation

### Using Poetry (Recommended)

```bash
# Clone the repository
git clone https://github.com/doantumy/ralph-coder.git
cd ralph-coder

# Install dependencies with Poetry
poetry install

# Run Ralph Coder
poetry run ralph-coder
```

### Using pip

```bash
# Clone the repository
git clone https://github.com/doantumy/ralph-coder.git
cd ralph-coder

# Install in editable mode
pip install -e .

# Run Ralph Coder
ralph-coder
```

## Configuration

Ralph Coder can be configured via environment variables or a `.env` file:

```bash
# Create .env file
cp .env.example .env

# Edit .env to customize Ollama host
OLLAMA_HOST=http://localhost:11434
```

## Quick Start

### Basic Usage

Start Ralph Coder with the default model:

```bash
poetry run ralph-coder
```

Or specify a model:

```bash
poetry run ralph-coder --model deepseek-coder
```

### Example Conversation

```
You: read pyproject.toml

[Ralph reads and displays the file]

You: What dependencies does this project use?

Ralph: Based on the pyproject.toml file I just read, this project uses:
- ollama: For connecting to local Ollama instances
- python-dotenv: For environment configuration
- rich: For terminal UI and formatting
- typer: For CLI argument parsing

The dev dependencies include mypy, ruff, and pytest.

You: search for "class.*Executor" --glob "*.py"

[Ralph searches and shows matches]

You: Can you add a timeout parameter to the CommandExecutor class?

[Ralph autonomously reads the file, makes the changes, and shows you a diff]
```

### Autonomous Mode

By default, Ralph can use tools automatically to complete tasks. To disable:

```bash
poetry run ralph-coder --no-tools
```

With tools disabled, you'll need to use manual commands (see below).

## Available Commands

Ralph Coder supports several slash commands for manual control:

### Basic Commands

- `/help` - Show help message with all commands
- `/exit` or `/quit` - Exit the REPL
- `/clear` - Clear conversation history
- `/stats` - Show conversation context statistics
- `/model [name]` - Switch to a different model or show current model

### File Operations

- `/read <file_path>` - Read and display a file
  ```
  /read src/main.py
  ```

- `/write <file_path>` - Write or overwrite a file (multi-line input)
  ```
  /write test.py
  [Type your content, end with blank line]
  ```

- `/replace <file_path> <search> <replace>` - Replace text in a file
  ```
  /replace config.py 'DEBUG = False' 'DEBUG = True'
  ```

### Code Search

- `/search <pattern> [--glob <pattern>] [-i]` - Search for patterns in files
  ```
  /search 'def main'
  /search 'TODO' --glob '*.py'
  /search 'error' -i
  ```

### Command Execution

- `/exec <command>` - Execute a shell command (requires confirmation)
  ```
  /exec poetry run pytest
  /exec git status
  /exec ls -la
  ```

## CLI Options

```bash
ralph-coder [OPTIONS]

Options:
  --model TEXT        Model to use (default: auto-detect best available)
  --host TEXT         Ollama host URL (default: http://localhost:11434)
  --enable-tools      Enable autonomous tool calling (default: enabled)
  --no-tools          Disable autonomous tool calling
  --help              Show help message
```

## Architecture Overview

Ralph Coder is built with a modular architecture:

```
ralph_coder/
├── cli.py                 # CLI entry point with Typer
├── repl.py                # Interactive REPL loop
├── ollama_client.py       # Ollama API client wrapper
├── session.py             # Session configuration
├── tools.py               # Tool calling system and parser
├── context_manager.py     # Conversation context management
├── file_operations.py     # File reading operations
├── file_editor.py         # File writing and editing
├── search.py              # Code search with ripgrep
└── command_executor.py    # Shell command execution
```

### Component Responsibilities

- **CLI**: Parses arguments, initializes Ollama client, starts REPL
- **REPL**: Main conversation loop, handles user input and LLM responses
- **Ollama Client**: Manages connection to local Ollama instance
- **Tools System**: Parses and executes tool calls from LLM responses
- **Context Manager**: Tracks token usage and trims conversation history
- **File Operations**: Reads files with syntax highlighting
- **File Editor**: Writes/edits files with diff preview and backups
- **Search**: Fast code search using ripgrep
- **Command Executor**: Runs shell commands with timeout and error handling

### Tool Calling Flow

1. User sends a message to the REPL
2. REPL adds message to conversation history
3. If tools enabled, REPL includes system prompt with tool instructions
4. LLM response may include `<tool_use>` XML blocks
5. Tool parser extracts and executes tool calls
6. Tool results are formatted and added to conversation
7. LLM continues with tool results until task is complete
8. Final response is shown to user

## Troubleshooting

### Ollama Connection Issues

**Error**: `Failed to connect to Ollama`

**Solution**:
- Check that Ollama is running: `ollama list`
- Verify the host URL in your `.env` file or via `--host` flag
- Default is `http://localhost:11434`

### No Models Available

**Error**: `No models available in Ollama`

**Solution**:
- Pull a model: `ollama pull deepseek-coder`
- List available models: `ollama list`

### ripgrep Not Found

**Warning**: `ripgrep (rg) not found - search functionality will be disabled`

**Solution**:
- Install ripgrep (see Prerequisites section)
- Search functionality is optional; other features work without it

### Type Check Failures

**Error**: Type errors when running `poetry run mypy`

**Solution**:
- Ralph Coder uses strict type checking with mypy
- All code must pass type checks before committing
- Check `pyproject.toml` for mypy configuration

### File Write Errors

**Error**: `Permission denied` when writing files

**Solution**:
- Ensure you have write permissions for the target directory
- Ralph Coder creates backups (.bak) before editing—ensure space is available

### Context Overflow

**Warning**: Context approaching limit

**Solution**:
- Use `/stats` to check current context usage
- Use `/clear` to reset conversation history
- Context is automatically trimmed at 80% capacity

## Development

### Running Quality Checks

```bash
# Type checking
poetry run mypy ralph_coder

# Linting and formatting
poetry run ruff check ralph_coder
poetry run ruff format ralph_coder

# Run tests
poetry run pytest
```

### Project Standards

- Python 3.11+ with modern type hints (`list[str]`, `X | None`)
- Strict mypy type checking enabled
- Ruff for linting and formatting (100 char line length)
- All code must pass type checks and linting before committing