# PRD: Open Source LLM Coding Agent

## Introduction

Build an interactive coding assistant that runs locally on developers' machines using open source LLMs through Ollama. The agent will help developers write code through natural conversation, understand codebases, make edits, run commands, and provide intelligent suggestions while maintaining full data privacy by running entirely on local infrastructure. The project will use Python 3.11+, Poetry for dependency management, and a modern Python toolchain.

## Goals

- Enable developers to interact with AI coding assistance using their own hardware and open source models
- Provide core coding capabilities: file reading/editing, codebase search, command execution, and code generation
- Support any Ollama-compatible LLM model with a unified interface
- Maintain conversation context across multi-turn interactions
- Deliver a minimal but functional MVP that proves the concept and can be extended

## User Stories

### US-001: Set up Python project and Ollama client integration
**Description:** As a developer, I need a Python project structure with Poetry and ollama-python library to connect to my local Ollama instance.

**Acceptance Criteria:**
- [ ] Create Python project using Poetry (poetry init or poetry new)
- [ ] Create pyproject.toml with Poetry configuration
- [ ] Add ollama-python as dependency using poetry add
- [ ] Add python-dotenv as dependency for configuration
- [ ] Add mypy, ruff (or black), pytest as dev dependencies
- [ ] Create basic Python module that can connect to Ollama API (default: http://localhost:11434)
- [ ] Support configurable Ollama endpoint via environment variable or .env file
- [ ] Detect available models using Ollama's `/api/tags` endpoint
- [ ] Handle connection errors gracefully with clear error messages
- [ ] Typecheck passes (using mypy)

### US-002: Implement model selection and configuration
**Description:** As a developer, I want to choose which Ollama model to use so I can balance performance vs. quality based on my hardware.

**Acceptance Criteria:**
- [ ] List available models from Ollama on startup
- [ ] Allow model selection via CLI flag (e.g., `--model deepseek-coder`)
- [ ] Default to a sensible model if available (e.g., `llama3` or `codellama`)
- [ ] Store selected model in session config
- [ ] Display current model in CLI prompt or status
- [ ] Typecheck/lint passes

### US-003: Create conversational REPL interface
**Description:** As a developer, I want to interact with the agent through a natural conversation interface so I can ask questions and request code changes iteratively.

**Acceptance Criteria:**
- [ ] CLI REPL that accepts multi-line input
- [ ] Display agent responses in readable format (markdown rendering preferred)
- [ ] Show thinking/processing indicator while waiting for LLM response
- [ ] Support basic commands: `/help`, `/exit`, `/clear`, `/model [name]`
- [ ] Maintain conversation history across turns in session
- [ ] Typecheck/lint passes

### US-004: Implement file reading capability
**Description:** As a developer, I want the agent to read files from my codebase so it can understand context before making suggestions.

**Acceptance Criteria:**
- [ ] Agent can read files when requested (e.g., "read src/main.py")
- [ ] Support both absolute and relative paths from working directory
- [ ] Display file contents to user when reading
- [ ] Include file content in context sent to LLM
- [ ] Handle file not found and permission errors gracefully
- [ ] Limit file size to prevent context overflow (e.g., max 10k lines)
- [ ] Typecheck/lint passes

### US-005: Implement code search capability
**Description:** As a developer, I want the agent to search my codebase for specific patterns so it can find relevant code without me specifying exact file paths.

**Acceptance Criteria:**
- [ ] Agent can search files using glob patterns (e.g., "search for *.py files containing 'def main'")
- [ ] Use ripgrep or similar fast search tool
- [ ] Display search results with file paths and line numbers
- [ ] Limit search results to prevent context overflow (e.g., top 20 matches)
- [ ] Support case-sensitive and case-insensitive search
- [ ] Typecheck/lint passes

### US-006: Implement file editing capability
**Description:** As a developer, I want the agent to make code changes to files so I don't have to manually apply suggested edits.

**Acceptance Criteria:**
- [ ] Agent can write new files or overwrite existing files
- [ ] Agent can apply targeted edits using search-and-replace
- [ ] Show diff preview before applying edits
- [ ] Require user confirmation before writing to disk (y/n prompt)
- [ ] Create backup of original file before editing (.bak extension)
- [ ] Handle write permission errors gracefully
- [ ] Typecheck/lint passes

### US-007: Implement command execution capability
**Description:** As a developer, I want the agent to run shell commands so it can run tests, install dependencies, and check build status.

**Acceptance Criteria:**
- [ ] Agent can execute bash commands in the working directory
- [ ] Display command output (stdout/stderr) to user
- [ ] Require user confirmation before running commands (y/n prompt)
- [ ] Set reasonable timeout (e.g., 60 seconds default)
- [ ] Support configurable working directory
- [ ] Capture exit codes and report failures clearly
- [ ] Typecheck/lint passes

### US-008: Implement tool-calling prompt system
**Description:** As a developer, I need the agent to understand when to use tools (read/search/edit/command) vs. just responding so it can autonomously accomplish tasks.

**Acceptance Criteria:**
- [ ] System prompt instructs LLM when and how to use available tools
- [ ] Define structured tool call format (e.g., JSON function calling or XML tags)
- [ ] Parse LLM responses to extract tool calls
- [ ] Execute requested tools and return results to LLM
- [ ] Support multiple tool calls in sequence within one conversation turn
- [ ] Fall back to text response if LLM doesn't use tools
- [ ] Typecheck/lint passes

### US-009: Add conversation context management
**Description:** As a developer, I want the agent to remember earlier parts of our conversation so I can reference previous context without repeating myself.

**Acceptance Criteria:**
- [ ] Maintain message history (user + assistant messages)
- [ ] Include file contents and tool results in context
- [ ] Implement basic context trimming when approaching model's context limit
- [ ] Preserve system prompt and recent messages when trimming
- [ ] Display context stats (e.g., token count) on request
- [ ] Typecheck/lint passes

### US-010: Create basic documentation and setup guide
**Description:** As a new user, I need clear documentation on how to install and use the agent so I can get started quickly.

**Acceptance Criteria:**
- [ ] README.md with installation instructions
- [ ] Prerequisites listed (Ollama installation, recommended models)
- [ ] Quick start guide with example conversation
- [ ] Available commands documented
- [ ] Architecture overview explaining how components work together
- [ ] Troubleshooting section for common issues

## Functional Requirements

**Core Agent Loop:**
- FR-1: Agent must accept user input through a CLI REPL interface
- FR-2: Agent must send conversation history + system prompt to configured Ollama model
- FR-3: Agent must parse LLM responses for tool calls or text responses
- FR-4: Agent must execute requested tools and return results to conversation context
- FR-5: Agent must display final responses to user in readable format

**Ollama Integration:**
- FR-6: Support connection to local Ollama instance (http://localhost:11434 by default)
- FR-7: Use Ollama's `/api/generate` or `/api/chat` endpoint for streaming responses
- FR-8: Allow model selection from available Ollama models
- FR-9: Handle Ollama connection failures with clear error messages

**Tool System:**
- FR-10: Implement file reading with path resolution relative to working directory
- FR-11: Implement code search using glob patterns and content matching
- FR-12: Implement file editing with both full-file writes and targeted edits
- FR-13: Implement bash command execution with output capture
- FR-14: Require user confirmation for destructive operations (edits, commands)
- FR-15: Display clear feedback for all tool executions (success/failure)

**Context Management:**
- FR-16: Maintain conversation history across turns in a session
- FR-17: Include system prompt with tool descriptions in every LLM request
- FR-18: Implement context window management to prevent token limit overflows
- FR-19: Support clearing conversation history with `/clear` command

**User Experience:**
- FR-20: Provide helpful error messages when things go wrong
- FR-21: Show processing indicators during LLM inference
- FR-22: Support markdown rendering for code blocks in responses
- FR-23: Allow graceful exit with `/exit` or Ctrl+C

## Non-Goals (Out of Scope)

- No web UI or GUI (CLI only for MVP)
- No cloud deployment or hosted service
- No multi-agent orchestration or agent-to-agent communication
- No fine-tuning or model training capabilities
- No built-in code review or quality scoring (beyond what LLM provides)
- No integration with external APIs or services (GitHub, Jira, etc.)
- No persistent storage of conversations across sessions
- No authentication or multi-user support
- No streaming response display (batch responses are acceptable for MVP)
- No support for non-Ollama LLM providers in MVP (can be added later)

## Design Considerations

**Tool Call Format:**
Choose between:
1. **JSON function calling** (structured, easier to parse, more reliable)
2. **XML tags** (simpler, but requires careful parsing)

Recommendation: Use JSON function calling if the chosen models support it well, otherwise use a simple XML-like format:
```
<tool>read_file</tool>
<args>
  <path>src/main.py</path>
</args>
```

**Architecture Sketch:**
```
┌─────────────────┐
│   CLI REPL      │
│  (User Input)   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Agent Core     │
│  - Context Mgmt │
│  - Tool Router  │
└────────┬────────┘
         │
         ├──────────────┬──────────────┬──────────────┐
         ▼              ▼              ▼              ▼
   ┌─────────┐   ┌──────────┐   ┌─────────┐   ┌──────────┐
   │ Ollama  │   │   File   │   │ Search  │   │  Command │
   │ Client  │   │  Tools   │   │  Tools  │   │  Exec    │
   └─────────┘   └──────────┘   └─────────┘   └──────────┘
```

**Technology Stack:**
- **Language:** Python 3.11+ (excellent LLM ecosystem, fast prototyping, rich tooling)
- **Package Manager:** Poetry (use pyproject.toml for dependency management)
- **CLI Framework:** Click or Typer for argument parsing and REPL
- **Ollama Client:** Official Ollama Python library (`ollama-python`)
- **Markdown Rendering:** Rich library for beautiful terminal output
- **Code Search:** Integrate with ripgrep binary via subprocess
- **Dev Tools:** mypy for typechecking, ruff or black for linting, pytest for testing

## Technical Considerations

**Context Window Management:**
- Most open source models have 4k-8k token context windows (some have 32k+)
- Need to track approximate token usage and trim old messages when approaching limit
- Keep system prompt + last N messages + current tool results
- Warn user when context is trimmed

**Model Compatibility:**
- Different models have different strengths (reasoning vs. code generation)
- System prompt may need tuning for different model families
- Some models follow instructions better than others for tool calling
- Recommend testing with: DeepSeek-Coder, Llama-3-8B, CodeLlama, Qwen-Coder

**Performance:**
- Local LLM inference can be slow on CPU-only machines
- Consider warning users about GPU acceleration benefits
- Implement timeout handling for hung LLM requests
- Consider adding early-stop tokens to reduce generation time

**Error Handling:**
- Ollama not running → clear message with setup instructions
- Model not found → list available models
- File permission errors → explain what went wrong and how to fix
- LLM returns malformed tool calls → ask LLM to retry with correct format

## Success Metrics

**MVP Success Criteria:**
- Developer can have a multi-turn conversation with the agent using their local Ollama setup
- Agent successfully reads files, searches code, and makes edits in at least 80% of attempts
- Agent correctly decides when to use tools vs. respond with text
- End-to-end interaction (question → tool use → response) completes in under 30 seconds on typical hardware
- Documentation clear enough that a developer can go from zero to first conversation in under 15 minutes

**Quality Metrics:**
- Tool call accuracy: >80% of tool calls have correct format and parameters
- Context retention: Agent remembers context from at least 5 turns back
- Error recovery: Agent gracefully handles at least 90% of error scenarios without crashing

## Open Questions

1. Should we support streaming responses in MVP, or is batch response acceptable?
2. What's the optimal default model to recommend? (needs testing across hardware profiles)
3. Should file edit confirmations be optional via flag for power users?
4. Do we need a plugin system for custom tools, or is the core set sufficient for MVP?
5. Should we support conversation save/load for persistent sessions, or keep MVP session-only?

## Implementation Notes

**Suggested Implementation Order:**
1. US-001: Set up Poetry project structure and Ollama integration
2. US-002: Add model selection and configuration
3. US-003: Build REPL so you can test interactively
4. US-008: Implement tool-calling system (can test with mock tools)
5. US-004, US-005, US-006, US-007: Add real tools one by one
6. US-009: Add context management once tools are working
7. US-010: Write documentation last when everything else works

**Testing Strategy:**
- Manual testing for MVP is acceptable
- Create sample codebase fixture for testing file operations
- Test with at least 2 different Ollama models (e.g., llama3 + deepseek-coder)
- Verify on both macOS and Linux if possible

## References

- [Ollama API Documentation](https://github.com/ollama/ollama/blob/main/docs/api.md)
- [Ollama Python Library](https://github.com/ollama/ollama-python)
- [Poetry Documentation](https://python-poetry.org/docs/) - Dependency management
- [Rich Python Library](https://github.com/Textualize/rich) - Terminal formatting and markdown
- [Click CLI Framework](https://click.palletsprojects.com/)
- [Typer CLI Framework](https://typer.tiangolo.com/) - Modern alternative to Click
- [mypy Documentation](https://mypy.readthedocs.io/) - Static type checking
- [Ruff](https://docs.astral.sh/ruff/) - Fast Python linter
- [Recommended Models for Coding](https://ollama.com/library) - Search for "code"
