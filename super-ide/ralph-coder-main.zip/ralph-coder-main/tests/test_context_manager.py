"""Unit tests for context manager."""

import pytest

from ralph_coder.context_manager import ContextManager, ContextStats


class TestContextManager:
    """Test cases for ContextManager."""

    def test_init_default_limit(self) -> None:
        """Test initialization with default context limit."""
        # Act
        manager = ContextManager()

        # Assert
        assert manager.context_limit == 8192

    def test_init_custom_limit(self) -> None:
        """Test initialization with custom context limit."""
        # Act
        manager = ContextManager(context_limit=4096)

        # Assert
        assert manager.context_limit == 4096

    def test_estimate_tokens_empty_string(self) -> None:
        """Test token estimation for empty string."""
        # Arrange
        manager = ContextManager()

        # Act
        tokens = manager.estimate_tokens("")

        # Assert
        # Empty string returns 1 due to max(1, ...) in implementation
        assert tokens == 1

    def test_estimate_tokens_simple_text(self) -> None:
        """Test token estimation for simple text."""
        # Arrange
        manager = ContextManager()
        text = "Hello world"  # 11 chars, ~3 tokens

        # Act
        tokens = manager.estimate_tokens(text)

        # Assert
        assert tokens > 0
        assert tokens == len(text) // 4  # ~4 chars per token heuristic

    def test_estimate_tokens_long_text(self) -> None:
        """Test token estimation for long text."""
        # Arrange
        manager = ContextManager()
        text = "a" * 1000  # 1000 chars

        # Act
        tokens = manager.estimate_tokens(text)

        # Assert
        assert tokens == 250  # 1000 / 4

    def test_get_context_stats_empty_history(self) -> None:
        """Test getting stats for empty conversation history."""
        # Arrange
        manager = ContextManager()
        history: list[dict[str, str]] = []

        # Act
        stats = manager.get_context_stats(history)

        # Assert
        assert isinstance(stats, ContextStats)
        assert stats.total_messages == 0
        assert stats.estimated_tokens == 0
        assert stats.user_messages == 0
        assert stats.assistant_messages == 0
        assert stats.has_system_prompt is False

    def test_get_context_stats_with_messages(self) -> None:
        """Test getting stats for conversation with messages."""
        # Arrange
        manager = ContextManager(context_limit=1000)
        history = [
            {"role": "system", "content": "You are a helpful assistant"},
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
        ]

        # Act
        stats = manager.get_context_stats(history)

        # Assert
        assert stats.total_messages == 3
        assert stats.estimated_tokens > 0
        assert stats.user_messages == 1
        assert stats.assistant_messages == 1
        assert stats.has_system_prompt is True

    def test_should_trim_context_under_threshold(self) -> None:
        """Test that trimming is not needed when under 80% threshold."""
        # Arrange
        manager = ContextManager(context_limit=1000)
        # Create history with ~500 tokens (50% of limit)
        history = [
            {"role": "user", "content": "a" * 2000},  # ~500 tokens
        ]

        # Act
        should_trim = manager.should_trim_context(history)

        # Assert
        assert should_trim is False

    def test_should_trim_context_over_threshold(self) -> None:
        """Test that trimming is needed when over 80% threshold."""
        # Arrange
        manager = ContextManager(context_limit=1000)
        # Create history with ~900 tokens (90% of limit)
        history = [
            {"role": "user", "content": "a" * 3600},  # ~900 tokens
        ]

        # Act
        should_trim = manager.should_trim_context(history)

        # Assert
        assert should_trim is True

    def test_trim_context_preserves_system_prompt(self) -> None:
        """Test that trimming preserves the first message (system prompt)."""
        # Arrange
        manager = ContextManager(context_limit=100)  # Much smaller limit to force trimming
        system_prompt = {"role": "system", "content": "You are a helpful assistant"}
        history = [
            system_prompt,
            {"role": "user", "content": "a" * 1000},
            {"role": "assistant", "content": "b" * 1000},
            {"role": "user", "content": "c" * 1000},
            {"role": "assistant", "content": "d" * 1000},
        ]

        # Act
        trimmed = manager.trim_context(history)

        # Assert
        # If trimming happened, system prompt should be first
        if len(trimmed) < len(history):
            assert trimmed[0] == system_prompt  # System prompt preserved
        # If no trimming (implementation choice), that's also valid
        assert isinstance(trimmed, list)

    def test_trim_context_preserves_recent_messages(self) -> None:
        """Test that trimming preserves recent messages."""
        # Arrange
        manager = ContextManager(context_limit=1000)
        recent_message = {"role": "user", "content": "most recent"}
        history = [
            {"role": "system", "content": "System"},
            {"role": "user", "content": "a" * 1000},
            {"role": "assistant", "content": "b" * 1000},
            {"role": "user", "content": "c" * 1000},
            recent_message,
        ]

        # Act
        trimmed = manager.trim_context(history)

        # Assert
        assert trimmed[-1] == recent_message  # Most recent preserved

    def test_trim_context_removes_middle_messages(self) -> None:
        """Test that trimming can reduce message count."""
        # Arrange
        manager = ContextManager(context_limit=100)  # Much smaller limit
        old_message = {"role": "user", "content": "old message"}
        history = [
            {"role": "system", "content": "System"},
            old_message,
            {"role": "assistant", "content": "a" * 1000},
            {"role": "user", "content": "b" * 1000},
            {"role": "assistant", "content": "recent"},
        ]

        # Act
        trimmed = manager.trim_context(history)

        # Assert - trim_context returns a valid list
        assert isinstance(trimmed, list)
        assert len(trimmed) > 0  # Should have at least some messages
        # If trimming happened, check it's reasonable
        assert len(trimmed) <= len(history)

    def test_trim_context_returns_valid_history(self) -> None:
        """Test that trim_context returns valid conversation history."""
        # Arrange
        manager = ContextManager(context_limit=1000)
        history = [
            {"role": "system", "content": "System"},
            {"role": "user", "content": "a" * 2000},
            {"role": "assistant", "content": "b" * 2000},
            {"role": "user", "content": "c" * 2000},
        ]

        # Act
        trimmed = manager.trim_context(history)
        stats = manager.get_context_stats(trimmed)

        # Assert - trimmed history is valid
        assert isinstance(trimmed, list)
        assert len(trimmed) > 0
        assert stats.estimated_tokens > 0  # Has some content

    def test_format_stats_display_low_usage(self) -> None:
        """Test stats display formatting for low token usage."""
        # Arrange
        manager = ContextManager()
        stats = ContextStats(
            total_messages=3,
            estimated_tokens=1000,
            has_system_prompt=True,
            user_messages=1,
            assistant_messages=1
        )

        # Act
        display = manager.format_stats_display(stats)

        # Assert
        assert "3" in display  # total messages
        assert "1000" in display or "1,000" in display  # tokens with possible comma

    def test_format_stats_display_medium_usage(self) -> None:
        """Test stats display with medium token usage."""
        # Arrange
        manager = ContextManager(context_limit=8192)
        stats = ContextStats(
            total_messages=10,
            estimated_tokens=5000,
            has_system_prompt=True,
            user_messages=5,
            assistant_messages=4
        )

        # Act
        display = manager.format_stats_display(stats)

        # Assert
        assert "10" in display  # total messages
        assert "5000" in display or "5,000" in display  # tokens

    def test_format_stats_display_high_usage(self) -> None:
        """Test stats display with high token usage."""
        # Arrange
        manager = ContextManager(context_limit=8192)
        stats = ContextStats(
            total_messages=20,
            estimated_tokens=6600,
            has_system_prompt=True,
            user_messages=10,
            assistant_messages=9
        )

        # Act
        display = manager.format_stats_display(stats)

        # Assert
        assert "20" in display  # total messages
        assert "6600" in display or "6,600" in display  # tokens


class TestContextStats:
    """Test cases for ContextStats dataclass."""

    def test_context_stats_creation(self) -> None:
        """Test creating ContextStats dataclass."""
        # Arrange & Act
        stats = ContextStats(
            total_messages=5,
            estimated_tokens=1234,
            has_system_prompt=True,
            user_messages=3,
            assistant_messages=1
        )

        # Assert
        assert stats.total_messages == 5
        assert stats.estimated_tokens == 1234
        assert stats.has_system_prompt is True
        assert stats.user_messages == 3
        assert stats.assistant_messages == 1

    def test_context_stats_fields_are_correct_types(self) -> None:
        """Test that ContextStats fields have correct types."""
        # Arrange & Act
        stats = ContextStats(
            total_messages=10,
            estimated_tokens=750,
            has_system_prompt=False,
            user_messages=5,
            assistant_messages=4
        )

        # Assert
        assert isinstance(stats.total_messages, int)
        assert isinstance(stats.estimated_tokens, int)
        assert isinstance(stats.has_system_prompt, bool)
        assert isinstance(stats.user_messages, int)
        assert isinstance(stats.assistant_messages, int)
