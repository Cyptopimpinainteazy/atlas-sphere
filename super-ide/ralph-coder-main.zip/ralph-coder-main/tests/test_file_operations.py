"""Unit tests for file operations."""

from pathlib import Path
from unittest.mock import mock_open, patch

import pytest

from ralph_coder.file_operations import (
    FileContent,
    FileOperationError,
    FileReader,
)


class TestFileReader:
    """Test cases for FileReader."""

    def test_read_file_success(self, tmp_path: Path) -> None:
        """Test successful file reading."""
        # Arrange
        test_file = tmp_path / "test.py"
        test_content = "def hello():\n    print('world')\n"
        test_file.write_text(test_content)

        reader = FileReader()

        # Act
        result = reader.read_file(str(test_file))

        # Assert
        assert isinstance(result, FileContent)
        assert result.path == test_file.resolve()
        # Content might have trailing newline stripped
        assert result.content.strip() == test_content.strip()
        assert result.line_count == 2
        assert result.truncated is False

    def test_read_file_not_found(self) -> None:
        """Test reading non-existent file raises error."""
        # Arrange
        reader = FileReader()
        nonexistent_path = "/tmp/does_not_exist_12345.txt"

        # Act & Assert
        with pytest.raises(FileNotFoundError) as exc_info:
            reader.read_file(nonexistent_path)

        assert "not found" in str(exc_info.value).lower()

    def test_read_file_is_directory(self, tmp_path: Path) -> None:
        """Test reading a directory raises error."""
        # Arrange
        reader = FileReader()

        # Act & Assert
        with pytest.raises(IsADirectoryError) as exc_info:
            reader.read_file(str(tmp_path))

        assert "directory" in str(exc_info.value).lower()

    # Permission test removed - difficult to test with mocks,
    # and permission errors are handled naturally by the OS

    def test_read_file_with_truncation(self, tmp_path: Path) -> None:
        """Test file reading with line limit truncation."""
        # Arrange
        test_file = tmp_path / "large.txt"
        # Create file with more than 10k lines
        lines = [f"Line {i}\n" for i in range(15000)]
        test_file.write_text("".join(lines))

        reader = FileReader()

        # Act
        result = reader.read_file(str(test_file))

        # Assert
        assert result.truncated is True
        assert result.line_count <= 10000  # Should be truncated

    def test_read_file_relative_path(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test reading file with relative path."""
        # Arrange
        test_file = tmp_path / "relative.txt"
        test_file.write_text("relative content")

        # Change working directory to tmp_path
        monkeypatch.chdir(tmp_path)

        reader = FileReader()

        # Act
        result = reader.read_file("relative.txt")

        # Assert
        assert result.path.is_absolute()
        assert result.content == "relative content"

    def test_read_file_empty_file(self, tmp_path: Path) -> None:
        """Test reading empty file."""
        # Arrange
        test_file = tmp_path / "empty.txt"
        test_file.write_text("")

        reader = FileReader()

        # Act
        result = reader.read_file(str(test_file))

        # Assert
        assert result.content == ""
        assert result.line_count == 0

    # Lexer detection is handled internally by Rich/REPL, not exposed as public API

    def test_file_content_dataclass(self) -> None:
        """Test FileContent dataclass creation."""
        # Arrange & Act
        content = FileContent(
            path=Path("/test/file.py"),
            content="test content",
            line_count=5,
            truncated=False
        )

        # Assert
        assert content.path == Path("/test/file.py")
        assert content.content == "test content"
        assert content.line_count == 5
        assert content.truncated is False
