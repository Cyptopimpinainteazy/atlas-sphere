"""Unit tests for OllamaClientWrapper."""

from unittest.mock import MagicMock, Mock, patch

import pytest

from ralph_coder.ollama_client import (
    ConnectionError,
    ModelNotFoundError,
    OllamaClientWrapper,
)


class TestOllamaClientWrapper:
    """Test cases for OllamaClientWrapper."""

    def test_init_with_default_host(self) -> None:
        """Test initialization with default host."""
        client = OllamaClientWrapper()
        assert client.host == "http://localhost:11434"

    def test_init_with_custom_host(self) -> None:
        """Test initialization with custom host."""
        custom_host = "http://custom:8080"
        client = OllamaClientWrapper(host=custom_host)
        assert client.host == custom_host

    @patch("ralph_coder.ollama_client.Client")
    def test_get_available_models_success(self, mock_client_class: Mock) -> None:
        """Test successful retrieval of available models.

        This test would have caught the Ollama API bug!
        """
        # Arrange - Mock the Ollama response format (ListResponse with .models attribute)
        mock_model1 = Mock()
        mock_model1.model = "llama3:latest"

        mock_model2 = Mock()
        mock_model2.model = "deepseek-coder:latest"

        mock_response = Mock()
        mock_response.models = [mock_model1, mock_model2]

        mock_client_instance = MagicMock()
        mock_client_instance.list.return_value = mock_response
        mock_client_class.return_value = mock_client_instance

        # Act
        client = OllamaClientWrapper()
        models = client.get_available_models()

        # Assert
        assert len(models) == 2
        assert "llama3:latest" in models
        assert "deepseek-coder:latest" in models
        assert isinstance(models, list)
        assert all(isinstance(m, str) for m in models)

    @patch("ralph_coder.ollama_client.Client")
    def test_get_available_models_empty_list(self, mock_client_class: Mock) -> None:
        """Test when no models are available."""
        # Arrange
        mock_response = Mock()
        mock_response.models = []

        mock_client_instance = MagicMock()
        mock_client_instance.list.return_value = mock_response
        mock_client_class.return_value = mock_client_instance

        # Act
        client = OllamaClientWrapper()
        models = client.get_available_models()

        # Assert
        assert models == []

    @patch("ralph_coder.ollama_client.Client")
    def test_get_available_models_connection_error(self, mock_client_class: Mock) -> None:
        """Test handling of connection errors."""
        # Arrange
        mock_client_instance = MagicMock()
        mock_client_instance.list.side_effect = Exception("Connection refused")
        mock_client_class.return_value = mock_client_instance

        # Act & Assert
        client = OllamaClientWrapper()
        with pytest.raises(ConnectionError) as exc_info:
            client.get_available_models()

        assert "Failed to retrieve models" in str(exc_info.value)
        assert "Connection refused" in str(exc_info.value)

    @patch("ralph_coder.ollama_client.Client")
    def test_test_connection_success(self, mock_client_class: Mock) -> None:
        """Test successful connection test."""
        # Arrange
        mock_response = Mock()
        mock_response.models = []

        mock_client_instance = MagicMock()
        mock_client_instance.list.return_value = mock_response
        mock_client_class.return_value = mock_client_instance

        # Act
        client = OllamaClientWrapper()
        result = client.test_connection()

        # Assert
        assert result is True

    @patch("ralph_coder.ollama_client.Client")
    def test_test_connection_failure(self, mock_client_class: Mock) -> None:
        """Test connection failure."""
        # Arrange
        mock_client_instance = MagicMock()
        mock_client_instance.list.side_effect = Exception("Network error")
        mock_client_class.return_value = mock_client_instance

        # Act & Assert
        client = OllamaClientWrapper()
        with pytest.raises(ConnectionError) as exc_info:
            client.test_connection()

        assert "Failed to connect to Ollama" in str(exc_info.value)

    @patch("ralph_coder.ollama_client.Client")
    def test_is_model_available_true(self, mock_client_class: Mock) -> None:
        """Test checking if a model is available (positive case)."""
        # Arrange
        mock_model = Mock()
        mock_model.model = "llama3:latest"

        mock_response = Mock()
        mock_response.models = [mock_model]

        mock_client_instance = MagicMock()
        mock_client_instance.list.return_value = mock_response
        mock_client_class.return_value = mock_client_instance

        # Act
        client = OllamaClientWrapper()
        result = client.is_model_available("llama3:latest")

        # Assert
        assert result is True

    @patch("ralph_coder.ollama_client.Client")
    def test_is_model_available_false(self, mock_client_class: Mock) -> None:
        """Test checking if a model is available (negative case)."""
        # Arrange
        mock_model = Mock()
        mock_model.model = "llama3:latest"

        mock_response = Mock()
        mock_response.models = [mock_model]

        mock_client_instance = MagicMock()
        mock_client_instance.list.return_value = mock_response
        mock_client_class.return_value = mock_client_instance

        # Act
        client = OllamaClientWrapper()
        result = client.is_model_available("nonexistent-model")

        # Assert
        assert result is False

    @patch("ralph_coder.ollama_client.Client")
    def test_chat_model_not_found(self, mock_client_class: Mock) -> None:
        """Test chat with unavailable model raises error."""
        # Arrange
        mock_response = Mock()
        mock_response.models = []

        mock_client_instance = MagicMock()
        mock_client_instance.list.return_value = mock_response
        mock_client_class.return_value = mock_client_instance

        # Act & Assert
        client = OllamaClientWrapper()
        messages = [{"role": "user", "content": "Hello"}]

        with pytest.raises(ModelNotFoundError) as exc_info:
            client.chat("nonexistent-model", messages)

        assert "not found" in str(exc_info.value)

    @patch("ralph_coder.ollama_client.Client")
    def test_chat_success_non_streaming(self, mock_client_class: Mock) -> None:
        """Test successful non-streaming chat."""
        # Arrange
        mock_model = Mock()
        mock_model.model = "llama3:latest"

        mock_list_response = Mock()
        mock_list_response.models = [mock_model]

        mock_chat_response = {"message": {"content": "Hello back!"}}

        mock_client_instance = MagicMock()
        mock_client_instance.list.return_value = mock_list_response
        mock_client_instance.chat.return_value = mock_chat_response
        mock_client_class.return_value = mock_client_instance

        # Act
        client = OllamaClientWrapper()
        messages = [{"role": "user", "content": "Hello"}]
        response = client.chat("llama3:latest", messages, stream=False)

        # Assert
        assert response == mock_chat_response
        mock_client_instance.chat.assert_called_once_with(
            model="llama3:latest",
            messages=messages,
            stream=False
        )
