"""Unit tests for tool calling system."""

import pytest

from ralph_coder.tools import (
    ToolCall,
    ToolCallParser,
    ToolResult,
    format_tool_result_for_llm,
    get_system_prompt,
)


class TestToolCallParser:
    """Test cases for ToolCallParser."""

    def test_parse_read_tool_call(self) -> None:
        """Test parsing a read tool call."""
        # Arrange
        parser = ToolCallParser()
        llm_response = """
Let me read that file for you.

<tool_use>
<tool_name>read</tool_name>
<parameters>
<path>src/main.py</path>
</parameters>
</tool_use>

I'll analyze it after reading.
"""

        # Act
        tool_calls, cleaned_text = parser.parse_response(llm_response)

        # Assert
        assert len(tool_calls) == 1
        assert tool_calls[0].tool_name == "read"
        assert "path" in tool_calls[0].parameters
        assert tool_calls[0].parameters["path"] == "src/main.py"

    def test_parse_search_tool_call(self) -> None:
        """Test parsing a search tool call."""
        # Arrange
        parser = ToolCallParser()
        llm_response = """
<tool_use>
<tool_name>search</tool_name>
<parameters>
<pattern>def main</pattern>
<glob>*.py</glob>
<case_sensitive>false</case_sensitive>
</parameters>
</tool_use>
"""

        # Act
        tool_calls, _ = parser.parse_response(llm_response)

        # Assert
        assert len(tool_calls) == 1
        assert tool_calls[0].tool_name == "search"
        assert tool_calls[0].parameters["pattern"] == "def main"
        assert tool_calls[0].parameters["glob"] == "*.py"
        assert tool_calls[0].parameters["case_sensitive"] == "false"

    def test_parse_write_tool_call(self) -> None:
        """Test parsing a write tool call."""
        # Arrange
        parser = ToolCallParser()
        llm_response = """
<tool_use>
<tool_name>write</tool_name>
<parameters>
<path>test.py</path>
<content>def hello():
    print("world")
</content>
</parameters>
</tool_use>
"""

        # Act
        tool_calls, _ = parser.parse_response(llm_response)

        # Assert
        assert len(tool_calls) == 1
        assert tool_calls[0].tool_name == "write"
        assert tool_calls[0].parameters["path"] == "test.py"
        assert "def hello():" in tool_calls[0].parameters["content"]
        assert 'print("world")' in tool_calls[0].parameters["content"]

    def test_parse_replace_tool_call(self) -> None:
        """Test parsing a replace tool call."""
        # Arrange
        parser = ToolCallParser()
        llm_response = """
<tool_use>
<tool_name>replace</tool_name>
<parameters>
<path>config.py</path>
<search>DEBUG = False</search>
<replace>DEBUG = True</replace>
</parameters>
</tool_use>
"""

        # Act
        tool_calls, _ = parser.parse_response(llm_response)

        # Assert
        assert len(tool_calls) == 1
        assert tool_calls[0].tool_name == "replace"
        assert tool_calls[0].parameters["path"] == "config.py"
        assert tool_calls[0].parameters["search"] == "DEBUG = False"
        assert tool_calls[0].parameters["replace"] == "DEBUG = True"

    def test_parse_execute_tool_call(self) -> None:
        """Test parsing an execute tool call."""
        # Arrange
        parser = ToolCallParser()
        llm_response = """
<tool_use>
<tool_name>execute</tool_name>
<parameters>
<command>poetry run pytest</command>
</parameters>
</tool_use>
"""

        # Act
        tool_calls, _ = parser.parse_response(llm_response)

        # Assert
        assert len(tool_calls) == 1
        assert tool_calls[0].tool_name == "execute"
        assert tool_calls[0].parameters["command"] == "poetry run pytest"

    def test_parse_multiple_tool_calls(self) -> None:
        """Test parsing multiple tool calls in sequence."""
        # Arrange
        parser = ToolCallParser()
        llm_response = """
First, let me read the file:

<tool_use>
<tool_name>read</tool_name>
<parameters>
<path>file1.py</path>
</parameters>
</tool_use>

Then I'll search for patterns:

<tool_use>
<tool_name>search</tool_name>
<parameters>
<pattern>TODO</pattern>
<glob>*.py</glob>
</parameters>
</tool_use>
"""

        # Act
        tool_calls, _ = parser.parse_response(llm_response)

        # Assert
        assert len(tool_calls) == 2
        assert tool_calls[0].tool_name == "read"
        assert tool_calls[0].parameters["path"] == "file1.py"
        assert tool_calls[1].tool_name == "search"
        assert tool_calls[1].parameters["pattern"] == "TODO"

    def test_parse_no_tool_calls(self) -> None:
        """Test parsing text with no tool calls."""
        # Arrange
        parser = ToolCallParser()
        llm_response = "This is just a regular response with no tool calls."

        # Act
        tool_calls, _ = parser.parse_response(llm_response)

        # Assert
        assert len(tool_calls) == 0

    def test_parse_malformed_xml(self) -> None:
        """Test parsing malformed XML gracefully."""
        # Arrange
        parser = ToolCallParser()
        llm_response = """
<tool_use>
<tool_name>read
<parameters>
<path>broken.py
</tool_use>
"""

        # Act
        tool_calls, _ = parser.parse_response(llm_response)

        # Assert - Should handle gracefully, not crash
        # Malformed XML might be skipped or partially parsed
        # The important thing is it doesn't raise an exception
        assert isinstance(tool_calls, list)

    def test_parse_missing_required_parameter(self) -> None:
        """Test parsing tool call with missing required parameter."""
        # Arrange
        parser = ToolCallParser()
        llm_response = """
<tool_use>
<tool_name>read</tool_name>
<parameters>
</parameters>
</tool_use>
"""

        # Act
        tool_calls, _ = parser.parse_response(llm_response)

        # Assert - Parser should still create the tool call
        # Validation happens later when executing
        assert len(tool_calls) == 1
        assert tool_calls[0].tool_name == "read"


class TestToolResult:
    """Test cases for ToolResult dataclass."""

    def test_tool_result_success(self) -> None:
        """Test creating successful tool result."""
        # Arrange & Act
        result = ToolResult(
            tool_name="read",
            success=True,
            output="File read successfully",
            error=None
        )

        # Assert
        assert result.tool_name == "read"
        assert result.success is True
        assert result.output == "File read successfully"
        assert result.error is None

    def test_tool_result_failure(self) -> None:
        """Test creating failed tool result."""
        # Arrange & Act
        result = ToolResult(
            tool_name="write",
            success=False,
            output="",
            error="File not found"
        )

        # Assert
        assert result.tool_name == "write"
        assert result.success is False
        assert result.output == ""
        assert result.error == "File not found"


class TestToolResultFormatting:
    """Test cases for tool result formatting."""

    def test_format_successful_result(self) -> None:
        """Test formatting successful tool result for LLM."""
        # Arrange
        result = ToolResult(
            tool_name="read",
            success=True,
            output="Content of file: def main(): pass",
            error=None
        )

        # Act
        formatted = format_tool_result_for_llm(result)

        # Assert
        assert "<tool_result>" in formatted
        assert "<tool_name>read</tool_name>" in formatted
        assert "<status>success</status>" in formatted
        assert "Content of file" in formatted
        assert "</tool_result>" in formatted

    def test_format_failed_result(self) -> None:
        """Test formatting failed tool result for LLM."""
        # Arrange
        result = ToolResult(
            tool_name="write",
            success=False,
            output="",
            error="Permission denied"
        )

        # Act
        formatted = format_tool_result_for_llm(result)

        # Assert
        assert "<tool_result>" in formatted
        assert "<tool_name>write</tool_name>" in formatted
        assert "<status>error</status>" in formatted
        assert "Permission denied" in formatted
        assert "<error>" in formatted


class TestSystemPrompt:
    """Test cases for system prompt generation."""

    def test_get_system_prompt_contains_tools(self) -> None:
        """Test that system prompt includes all tool descriptions."""
        # Act
        prompt = get_system_prompt()

        # Assert - Check for all 5 tools
        assert "read" in prompt.lower()
        assert "search" in prompt.lower()
        assert "write" in prompt.lower()
        assert "replace" in prompt.lower()
        assert "execute" in prompt.lower()

    def test_get_system_prompt_has_examples(self) -> None:
        """Test that system prompt includes usage examples."""
        # Act
        prompt = get_system_prompt()

        # Assert - Should have XML format examples
        assert "<tool_use>" in prompt
        assert "<tool_name>" in prompt
        assert "<parameters>" in prompt

    def test_get_system_prompt_is_string(self) -> None:
        """Test that system prompt returns a string."""
        # Act
        prompt = get_system_prompt()

        # Assert
        assert isinstance(prompt, str)
        assert len(prompt) > 100  # Should be substantial
