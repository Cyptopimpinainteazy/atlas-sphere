# Quickstart

1. Extract and run coordinator: ./swarm-coordinator --config coordinator-config.toml
2. Start node: ./swarm-node --config node-config.toml
